<?php
/**
 * Title: Hero — Centered
 * Slug: acorn/hero-centered
 * Categories: acorn-hero
 * Description: Centered headline, supporting text and a two-button group on a full-width band.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","metadata":{"name":"Hero — Centered"},"className":"acorn-pattern-hero-centered","backgroundColor":"bg-4","style":{"spacing":{"padding":{"top":"var:preset|spacing|humungous","bottom":"var:preset|spacing|humungous"},"blockGap":"var:preset|spacing|small"}},"layout":{"type":"constrained"}} -->
<section class="wp-block-group acorn-pattern-hero-centered alignfull has-global-padding has-bg-4-background-color has-background" style="padding-top:var(--wp--preset--spacing--humungous);padding-bottom:var(--wp--preset--spacing--humungous)">
<!-- wp:heading {"textAlign":"center","level":1} -->
<h1 class="wp-block-heading has-text-align-center">A clear, benefit-led headline</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">One or two supporting sentences that explain the offer and set up the call to action below.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|small"}}},"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--small)">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Primary action</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-secondary"} -->
<div class="wp-block-button is-style-secondary"><a class="wp-block-button__link wp-element-button">Secondary</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</section>
<!-- /wp:group -->
