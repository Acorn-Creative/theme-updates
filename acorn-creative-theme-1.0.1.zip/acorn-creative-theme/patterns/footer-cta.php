<?php
/**
 * Title: Footer CTA — Sign-off
 * Slug: acorn/footer-cta
 * Categories: acorn-footer-cta
 * Description: Closing full-width band with a heading and two actions to end a page.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","metadata":{"name":"Footer CTA — Sign-off"},"className":"acorn-pattern-footer-cta","backgroundColor":"bg-1","style":{"spacing":{"padding":{"top":"var:preset|spacing|humungous","bottom":"var:preset|spacing|humungous"},"blockGap":"var:preset|spacing|small"}},"layout":{"type":"constrained"}} -->
<section class="wp-block-group acorn-pattern-footer-cta alignfull has-global-padding has-bg-1-background-color has-background" style="padding-top:var(--wp--preset--spacing--humungous);padding-bottom:var(--wp--preset--spacing--humungous)">
<!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center">Let's build something together</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Close the page with a warm, direct invitation and give the visitor two clear ways to act.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|small"}}},"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--small)">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Start a project</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-secondary"} -->
<div class="wp-block-button is-style-secondary"><a class="wp-block-button__link wp-element-button">Book a call</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</section>
<!-- /wp:group -->
