<?php
/**
 * Title: FAQ — Accordion
 * Slug: acorn/faq-accordion
 * Categories: acorn-faq
 * Description: Stacked expand/collapse questions built on the native Accordion block.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","metadata":{"name":"FAQ — Accordion"},"className":"acorn-pattern-faq-accordion","backgroundColor":"bg-4","style":{"spacing":{"padding":{"top":"var:preset|spacing|humungous","bottom":"var:preset|spacing|humungous"},"blockGap":"var:preset|spacing|large"}},"layout":{"type":"constrained"}} -->
<section class="wp-block-group acorn-pattern-faq-accordion alignfull has-global-padding has-bg-4-background-color has-background" style="padding-top:var(--wp--preset--spacing--humungous);padding-bottom:var(--wp--preset--spacing--humungous)">
<!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center">Frequently asked questions</h2>
<!-- /wp:heading -->

<!-- wp:accordion -->
<div role="group" class="wp-block-accordion">
<!-- wp:accordion-item -->
<div class="wp-block-accordion-item">
<!-- wp:accordion-heading -->
<h3 class="wp-block-accordion-heading has-icon has-icon-right"><button type="button" class="wp-block-accordion-heading__toggle"><span class="wp-block-accordion-heading__toggle-title">The first common question</span><span class="wp-block-accordion-heading__toggle-icon" aria-hidden="true">+</span></button></h3>
<!-- /wp:accordion-heading -->

<!-- wp:accordion-panel -->
<div role="region" class="wp-block-accordion-panel">
<!-- wp:paragraph -->
<p>A concise answer. Keep it to a few sentences and link out if the visitor needs more detail.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:accordion-panel -->
</div>
<!-- /wp:accordion-item -->

<!-- wp:accordion-item -->
<div class="wp-block-accordion-item">
<!-- wp:accordion-heading -->
<h3 class="wp-block-accordion-heading has-icon has-icon-right"><button type="button" class="wp-block-accordion-heading__toggle"><span class="wp-block-accordion-heading__toggle-title">A second question people ask</span><span class="wp-block-accordion-heading__toggle-icon" aria-hidden="true">+</span></button></h3>
<!-- /wp:accordion-heading -->

<!-- wp:accordion-panel -->
<div role="region" class="wp-block-accordion-panel">
<!-- wp:paragraph -->
<p>A concise answer. Keep it to a few sentences and link out if the visitor needs more detail.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:accordion-panel -->
</div>
<!-- /wp:accordion-item -->

<!-- wp:accordion-item -->
<div class="wp-block-accordion-item">
<!-- wp:accordion-heading -->
<h3 class="wp-block-accordion-heading has-icon has-icon-right"><button type="button" class="wp-block-accordion-heading__toggle"><span class="wp-block-accordion-heading__toggle-title">A third question worth answering</span><span class="wp-block-accordion-heading__toggle-icon" aria-hidden="true">+</span></button></h3>
<!-- /wp:accordion-heading -->

<!-- wp:accordion-panel -->
<div role="region" class="wp-block-accordion-panel">
<!-- wp:paragraph -->
<p>A concise answer. Keep it to a few sentences and link out if the visitor needs more detail.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:accordion-panel -->
</div>
<!-- /wp:accordion-item -->
</div>
<!-- /wp:accordion -->
</section>
<!-- /wp:group -->
