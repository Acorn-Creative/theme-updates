<?php
/**
 * Title: Overlap — Card Over Two Bands
 * Slug: acorn/overlap-card-trio
 * Categories: acorn-overlap
 * Description: Three bands where the middle one is a card pulled over the seam between the two around it.
 *
 * Three SIBLING sections, not a nested stack — the middle one carries
 * `acorn-overlap-both` and pulls into the two around it. All three ship in one
 * pattern because the overlap is a contract between them, not a property of the
 * middle band alone.
 *
 * RESTYLE A NEIGHBOUR AND YOU MUST RESTYLE ITS `acorn-overlap-above--{slug}` /
 * `acorn-overlap-below--{slug}` CLASS HERE.
 *
 * The three rules this pattern has to keep, and why: CLAUDE.md § Patterns.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","metadata":{"name":"Overlap — Band Above"},"className":"acorn-pattern-overlap-card-trio acorn-pattern-overlap-card-trio--above","backgroundColor":"bg-1","style":{"spacing":{"padding":{"top":"var:preset|spacing|humungous","bottom":"var:preset|spacing|humungous"},"blockGap":"var:preset|spacing|small"}},"layout":{"type":"constrained"}} -->
<section class="wp-block-group acorn-pattern-overlap-card-trio acorn-pattern-overlap-card-trio--above alignfull has-global-padding has-bg-1-background-color has-background" style="padding-top:var(--wp--preset--spacing--humungous);padding-bottom:var(--wp--preset--spacing--humungous)">
<!-- wp:heading -->
<h2 class="wp-block-heading">The band the card reaches up into</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>This band pads plain <code>humungous</code>. The overlap is added back by a spacer the stylesheet puts here, so the gap you see above the card matches this band's own top padding — and keeps matching if you change the padding.</p>
<!-- /wp:paragraph -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","align":"full","metadata":{"name":"Overlap — Card"},"className":"acorn-pattern-overlap-card-trio acorn-pattern-overlap-card-trio--card acorn-overlap-both acorn-overlap-above--bg-1 acorn-overlap-below--bg-2","style":{"spacing":{"padding":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->
<section class="wp-block-group acorn-pattern-overlap-card-trio acorn-pattern-overlap-card-trio--card acorn-overlap-both acorn-overlap-above--bg-1 acorn-overlap-below--bg-2 alignfull has-global-padding" style="padding-top:0;padding-bottom:0">
<!-- wp:group {"backgroundColor":"bg-4","style":{"spacing":{"padding":{"top":"var:preset|spacing|medium","bottom":"var:preset|spacing|medium","left":"var:preset|spacing|large","right":"var:preset|spacing|large"},"blockGap":"var:preset|spacing|small"},"shadow":"var:preset|shadow|shadow-md"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group has-bg-4-background-color has-background" style="box-shadow:var(--wp--preset--shadow--shadow-md);padding-top:var(--wp--preset--spacing--medium);padding-right:var(--wp--preset--spacing--large);padding-bottom:var(--wp--preset--spacing--medium);padding-left:var(--wp--preset--spacing--large)">
<!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center">The point you want read first</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Sitting across the seam is what earns this block its emphasis, so give it one idea and one action — not a second column of copy.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|small"}}},"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--small)">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Primary action</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","align":"full","metadata":{"name":"Overlap — Band Below"},"className":"acorn-pattern-overlap-card-trio acorn-pattern-overlap-card-trio--below","backgroundColor":"bg-2","style":{"spacing":{"padding":{"top":"var:preset|spacing|humungous","bottom":"var:preset|spacing|humungous"},"blockGap":"var:preset|spacing|small"}},"layout":{"type":"constrained"}} -->
<section class="wp-block-group acorn-pattern-overlap-card-trio acorn-pattern-overlap-card-trio--below alignfull has-global-padding has-bg-2-background-color has-background" style="padding-top:var(--wp--preset--spacing--humungous);padding-bottom:var(--wp--preset--spacing--humungous)">
<!-- wp:heading -->
<h2 class="wp-block-heading">The band the card reaches down into</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Same on this side. Change the padding or the scheme freely — but if you change the scheme, update <code>acorn-overlap-below--bg-2</code> on the middle band to match, or the seam behind the card stops lining up.</p>
<!-- /wp:paragraph -->
</section>
<!-- /wp:group -->
