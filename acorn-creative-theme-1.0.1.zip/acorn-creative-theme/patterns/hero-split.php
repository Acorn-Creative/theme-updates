<?php
/**
 * Title: Hero — Split Media
 * Slug: acorn/hero-split
 * Categories: acorn-hero
 * Description: Two-column hero with copy on the left and an image placeholder on the right.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","metadata":{"name":"Hero — Split Media"},"className":"acorn-pattern-hero-split","backgroundColor":"bg-1","style":{"spacing":{"padding":{"top":"var:preset|spacing|humungous","bottom":"var:preset|spacing|humungous"}}},"layout":{"type":"constrained"}} -->
<section class="wp-block-group acorn-pattern-hero-split alignfull has-global-padding has-bg-1-background-color has-background" style="padding-top:var(--wp--preset--spacing--humungous);padding-bottom:var(--wp--preset--spacing--humungous)">
<!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|large","left":"var:preset|spacing|large"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"blockGap":"var:preset|spacing|small"}}} -->
<div class="wp-block-column is-vertically-aligned-center">
<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">A headline that leads with the outcome</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Supporting copy that expands on the promise and gives the visitor a reason to keep reading.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|small"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--small)">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Primary action</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center">
<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img alt=""/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</section>
<!-- /wp:group -->
