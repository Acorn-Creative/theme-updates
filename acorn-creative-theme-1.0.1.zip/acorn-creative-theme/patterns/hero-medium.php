<?php
/**
 * Title: Hero — Medium
 * Slug: acorn/hero-medium
 * Categories: acorn-hero
 * Description: Balanced left-aligned hero — headline, supporting paragraph and a two-button group on a full-width band.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","metadata":{"name":"Hero — Medium"},"className":"acorn-pattern-hero-medium","backgroundColor":"bg-3","style":{"spacing":{"padding":{"top":"var:preset|spacing|humungous","bottom":"var:preset|spacing|humungous"},"blockGap":"var:preset|spacing|small"}},"layout":{"type":"constrained"}} -->
<section class="wp-block-group acorn-pattern-hero-medium alignfull has-global-padding has-bg-3-background-color has-background" style="padding-top:var(--wp--preset--spacing--humungous);padding-bottom:var(--wp--preset--spacing--humungous)">
<!-- wp:heading {"level":1} -->
<h1 class="wp-block-heading">A clear headline with room to breathe</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>One or two supporting sentences that explain the offer and give the visitor a reason to act.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|small"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--small)">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Primary action</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-secondary"} -->
<div class="wp-block-button is-style-secondary"><a class="wp-block-button__link wp-element-button">Secondary</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</section>
<!-- /wp:group -->
