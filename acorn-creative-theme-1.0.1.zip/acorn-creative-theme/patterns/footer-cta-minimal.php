<?php
/**
 * Title: Footer CTA — Minimal
 * Slug: acorn/footer-cta-minimal
 * Categories: acorn-footer-cta
 * Description: Compact single-row sign-off — one heading and one action on a light band.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","metadata":{"name":"Footer CTA — Minimal"},"className":"acorn-pattern-footer-cta-minimal","backgroundColor":"bg-4","style":{"spacing":{"padding":{"top":"var:preset|spacing|medium","bottom":"var:preset|spacing|medium"}}},"layout":{"type":"constrained"}} -->
<section class="wp-block-group acorn-pattern-footer-cta-minimal alignfull has-global-padding has-bg-4-background-color has-background" style="padding-top:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--medium)">
<!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|small"}},"layout":{"type":"flex","flexWrap":"wrap","justifyContent":"space-between","verticalAlignment":"center"}} -->
<div class="wp-block-group">
<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Ready when you are</h3>
<!-- /wp:heading -->

<!-- wp:buttons -->
<div class="wp-block-buttons">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Get in touch</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->
