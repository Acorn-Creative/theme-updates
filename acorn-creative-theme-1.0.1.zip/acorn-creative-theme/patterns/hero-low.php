<?php
/**
 * Title: Hero — Low
 * Slug: acorn/hero-low
 * Categories: acorn-hero
 * Description: Compact, understated hero — a smaller headline, a short line of copy and a single call to action.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","metadata":{"name":"Hero — Low"},"className":"acorn-pattern-hero-low","backgroundColor":"bg-4","style":{"spacing":{"padding":{"top":"var:preset|spacing|medium","bottom":"var:preset|spacing|medium"},"blockGap":"var:preset|spacing|small"}},"layout":{"type":"constrained"}} -->
<section class="wp-block-group acorn-pattern-hero-low alignfull has-global-padding has-bg-4-background-color has-background" style="padding-top:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--medium)">
<!-- wp:heading {"level":1,"className":"is-style-h2"} -->
<h1 class="wp-block-heading is-style-h2">A concise, low-key headline</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A single supporting sentence — just enough context before the call to action.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|extra-small"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--extra-small)">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Learn more</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</section>
<!-- /wp:group -->
