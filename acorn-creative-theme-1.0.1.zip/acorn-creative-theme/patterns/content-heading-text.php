<?php
/**
 * Title: Content — Heading & Text
 * Slug: acorn/content-heading-text
 * Categories: acorn-content
 * Description: A simple prose section with a heading, intro and body copy.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","metadata":{"name":"Content — Heading & Text"},"className":"acorn-pattern-content-heading-text","backgroundColor":"bg-4","style":{"spacing":{"padding":{"top":"var:preset|spacing|extra-large","bottom":"var:preset|spacing|extra-large"},"blockGap":"var:preset|spacing|small"}},"layout":{"type":"constrained"}} -->
<section class="wp-block-group acorn-pattern-content-heading-text alignfull has-global-padding has-bg-4-background-color has-background" style="padding-top:var(--wp--preset--spacing--extra-large);padding-bottom:var(--wp--preset--spacing--extra-large)">
<!-- wp:heading -->
<h2 class="wp-block-heading">A section heading</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>An introductory paragraph that frames what this section covers. Keep it to a couple of sentences so the reader knows what follows.</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph -->
<p>Body copy continues here. This band runs to the site's full content width — if the section carries a lot of prose, narrow it on the group's own layout controls so the measure stays readable.</p>
<!-- /wp:paragraph -->
</section>
<!-- /wp:group -->
