<?php
/**
 * Title: CTA — Centered Band
 * Slug: acorn/cta-band
 * Categories: acorn-cta
 * Description: High-contrast full-width call-to-action band with a single button.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","metadata":{"name":"CTA — Centered Band"},"className":"acorn-pattern-cta-band","backgroundColor":"bg-1","style":{"spacing":{"padding":{"top":"var:preset|spacing|extra-large","bottom":"var:preset|spacing|extra-large"},"blockGap":"var:preset|spacing|small"}},"layout":{"type":"constrained"}} -->
<section class="wp-block-group acorn-pattern-cta-band alignfull has-global-padding has-bg-1-background-color has-background" style="padding-top:var(--wp--preset--spacing--extra-large);padding-bottom:var(--wp--preset--spacing--extra-large)">
<!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center">Ready to get started?</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">A single sentence that restates the value and removes the last bit of hesitation.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|small"}}},"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--small)">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Get in touch</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</section>
<!-- /wp:group -->
