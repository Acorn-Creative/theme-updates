<?php
/**
 * Title: Overlap — Media Over Two Bands
 * Slug: acorn/overlap-media-trio
 * Categories: acorn-overlap
 * Description: Three bands where the middle one is an image-and-copy row pulled over the seam between the two around it.
 *
 * Same three-sibling structure and the same contract as
 * `acorn/overlap-card-trio` — CLAUDE.md § Patterns.
 *
 * What differs: the overlapping surface is a two-column row, so it is taller
 * than a copy card and the pull is `acorn-overlap--small` (2rem) rather than the
 * 4rem default. The size class is per-instance for exactly this reason — a tall
 * surface needs less pull to read as overlapping, a short one more.
 *
 * The neighbours need no adjusting: their spacer is selected by the size class
 * on the middle band, so it tracks automatically.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","metadata":{"name":"Overlap — Band Above"},"className":"acorn-pattern-overlap-media-trio acorn-pattern-overlap-media-trio--above","backgroundColor":"bg-1","style":{"spacing":{"padding":{"top":"var:preset|spacing|humungous","bottom":"var:preset|spacing|humungous"},"blockGap":"var:preset|spacing|small"}},"layout":{"type":"constrained"}} -->
<section class="wp-block-group acorn-pattern-overlap-media-trio acorn-pattern-overlap-media-trio--above alignfull has-global-padding has-bg-1-background-color has-background" style="padding-top:var(--wp--preset--spacing--humungous);padding-bottom:var(--wp--preset--spacing--humungous)">
<!-- wp:heading -->
<h2 class="wp-block-heading">The band the row reaches up into</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>This band pads plain <code>humungous</code>. The overlap is added back by a spacer the stylesheet puts here, so the gap you see above the row matches this band's own top padding — and keeps matching if you change the padding.</p>
<!-- /wp:paragraph -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","align":"full","metadata":{"name":"Overlap — Media Row"},"className":"acorn-pattern-overlap-media-trio acorn-pattern-overlap-media-trio--row acorn-overlap-both acorn-overlap--small acorn-overlap-above--bg-1 acorn-overlap-below--bg-3","style":{"spacing":{"padding":{"top":"0","bottom":"0"}}},"layout":{"type":"constrained"}} -->
<section class="wp-block-group acorn-pattern-overlap-media-trio acorn-pattern-overlap-media-trio--row acorn-overlap-both acorn-overlap--small acorn-overlap-above--bg-1 acorn-overlap-below--bg-3 alignfull has-global-padding" style="padding-top:0;padding-bottom:0">
<!-- wp:group {"backgroundColor":"bg-4","style":{"spacing":{"padding":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large","left":"var:preset|spacing|large","right":"var:preset|spacing|large"}},"shadow":"var:preset|shadow|shadow-md"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group has-bg-4-background-color has-background" style="box-shadow:var(--wp--preset--shadow--shadow-md);padding-top:var(--wp--preset--spacing--large);padding-right:var(--wp--preset--spacing--large);padding-bottom:var(--wp--preset--spacing--large);padding-left:var(--wp--preset--spacing--large)">
<!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|large","left":"var:preset|spacing|large"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center">
<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img alt=""/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"blockGap":"var:preset|spacing|small"}}} -->
<div class="wp-block-column is-vertically-aligned-center">
<!-- wp:heading -->
<h2 class="wp-block-heading">One idea, shown and said</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A row this wide earns its place by straddling the seam, so it should carry the section's single most important claim.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|small"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--small)">
<!-- wp:button {"className":"is-style-secondary"} -->
<div class="wp-block-button is-style-secondary"><a class="wp-block-button__link wp-element-button">Secondary action</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","align":"full","metadata":{"name":"Overlap — Band Below"},"className":"acorn-pattern-overlap-media-trio acorn-pattern-overlap-media-trio--below","backgroundColor":"bg-3","style":{"spacing":{"padding":{"top":"var:preset|spacing|humungous","bottom":"var:preset|spacing|humungous"},"blockGap":"var:preset|spacing|small"}},"layout":{"type":"constrained"}} -->
<section class="wp-block-group acorn-pattern-overlap-media-trio acorn-pattern-overlap-media-trio--below alignfull has-global-padding has-bg-3-background-color has-background" style="padding-top:var(--wp--preset--spacing--humungous);padding-bottom:var(--wp--preset--spacing--humungous)">
<!-- wp:heading -->
<h2 class="wp-block-heading">The band the row reaches down into</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Same on this side. Change the padding or the scheme freely — but if you change the scheme, update <code>acorn-overlap-below--bg-3</code> on the middle band to match, or the seam behind the row stops lining up.</p>
<!-- /wp:paragraph -->
</section>
<!-- /wp:group -->
