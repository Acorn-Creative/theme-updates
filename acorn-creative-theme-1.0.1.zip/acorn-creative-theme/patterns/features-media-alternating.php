<?php
/**
 * Title: Features — Media & Text
 * Slug: acorn/features-media-alternating
 * Categories: acorn-features
 * Description: Image beside a copy block, ready to be duplicated and alternated down the page.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","metadata":{"name":"Features — Media & Text"},"className":"acorn-pattern-features-media-alternating","backgroundColor":"bg-3","style":{"spacing":{"padding":{"top":"var:preset|spacing|humungous","bottom":"var:preset|spacing|humungous"}}},"layout":{"type":"constrained"}} -->
<section class="wp-block-group acorn-pattern-features-media-alternating alignfull has-global-padding has-bg-3-background-color has-background" style="padding-top:var(--wp--preset--spacing--humungous);padding-bottom:var(--wp--preset--spacing--humungous)">
<!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|large","left":"var:preset|spacing|large"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center">
<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img alt=""/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"blockGap":"var:preset|spacing|small"}}} -->
<div class="wp-block-column is-vertically-aligned-center">
<!-- wp:heading {"level":2} -->
<h2 class="wp-block-heading">Explain a single idea well</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Use one of these rows per idea. Duplicate the section and swap the image column side to alternate the layout down the page.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</section>
<!-- /wp:group -->
