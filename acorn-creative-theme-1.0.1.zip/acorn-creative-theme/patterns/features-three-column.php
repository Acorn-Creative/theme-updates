<?php
/**
 * Title: Features — Three Columns
 * Slug: acorn/features-three-column
 * Categories: acorn-features
 * Description: Centered eyebrow, heading and intro above a responsive three-up grid of equal-height feature cards, closing on a minimal link.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","metadata":{"name":"Features — Three Columns"},"className":"acorn-pattern-features-three-column","backgroundColor":"bg-4","style":{"spacing":{"padding":{"top":"var:preset|spacing|humungous","bottom":"var:preset|spacing|humungous"},"blockGap":"var:preset|spacing|small"}},"layout":{"type":"constrained"}} -->
<section class="wp-block-group acorn-pattern-features-three-column alignfull has-global-padding has-bg-4-background-color has-background" style="padding-top:var(--wp--preset--spacing--humungous);padding-bottom:var(--wp--preset--spacing--humungous)">
<!-- wp:paragraph {"align":"center","className":"is-style-pre-header"} -->
<p class="has-text-align-center is-style-pre-header">Why work with us</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center">What sets us apart</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","className":"is-style-intro"} -->
<p class="has-text-align-center is-style-intro">One or two sentences framing the three points below, so the grid reads as an argument rather than a list.</p>
<!-- /wp:paragraph -->

<!-- wp:group {"style":{"spacing":{"margin":{"top":"var:preset|spacing|large"},"blockGap":"var:preset|spacing|medium"}},"layout":{"type":"grid","columnCount":3,"minimumColumnWidth":"16rem"}} -->
<div class="wp-block-group" style="margin-top:var(--wp--preset--spacing--large)">
<!-- wp:group {"backgroundColor":"bg-3","style":{"spacing":{"padding":{"top":"var:preset|spacing|medium","right":"var:preset|spacing|medium","bottom":"var:preset|spacing|medium","left":"var:preset|spacing|medium"},"blockGap":"var:preset|spacing|tiny"}}} -->
<div class="wp-block-group has-bg-3-background-color has-background" style="padding-top:var(--wp--preset--spacing--medium);padding-right:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--medium);padding-left:var(--wp--preset--spacing--medium)">
<!-- wp:paragraph {"className":"is-style-pre-header"} -->
<p class="is-style-pre-header">01</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">First feature</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A short description of the benefit and why it matters to the visitor.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"backgroundColor":"bg-3","style":{"spacing":{"padding":{"top":"var:preset|spacing|medium","right":"var:preset|spacing|medium","bottom":"var:preset|spacing|medium","left":"var:preset|spacing|medium"},"blockGap":"var:preset|spacing|tiny"}}} -->
<div class="wp-block-group has-bg-3-background-color has-background" style="padding-top:var(--wp--preset--spacing--medium);padding-right:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--medium);padding-left:var(--wp--preset--spacing--medium)">
<!-- wp:paragraph {"className":"is-style-pre-header"} -->
<p class="is-style-pre-header">02</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Second feature</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A short description of the benefit and why it matters to the visitor.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->

<!-- wp:group {"backgroundColor":"bg-3","style":{"spacing":{"padding":{"top":"var:preset|spacing|medium","right":"var:preset|spacing|medium","bottom":"var:preset|spacing|medium","left":"var:preset|spacing|medium"},"blockGap":"var:preset|spacing|tiny"}}} -->
<div class="wp-block-group has-bg-3-background-color has-background" style="padding-top:var(--wp--preset--spacing--medium);padding-right:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--medium);padding-left:var(--wp--preset--spacing--medium)">
<!-- wp:paragraph {"className":"is-style-pre-header"} -->
<p class="is-style-pre-header">03</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Third feature</h3>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A short description of the benefit and why it matters to the visitor.</p>
<!-- /wp:paragraph -->
</div>
<!-- /wp:group -->
</div>
<!-- /wp:group -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|large"}}},"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--large)">
<!-- wp:button {"className":"is-style-minimal"} -->
<div class="wp-block-button is-style-minimal"><a class="wp-block-button__link wp-element-button">See everything we do</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</section>
<!-- /wp:group -->
