// =============================================================
//  Scroll-Reveal Animations — Block Editor Toolbar Control
// =============================================================
//  Adds an "Animate" toolbar button (enable toggle, direction select,
//  speed/offset sliders) to an allowlist of STATIC-SAVE core blocks, and a
//  "Stagger children" toggle on the containers in STAGGER_BLOCKS.
//
//  Serialized to the saved markup by blocks.getSaveContent.extraProps:
//    animDirection → class `anim-<dir>`
//    animDuration  → inline `--anim-duration`
//    animDelay     → inline `--anim-delay` (start offset)
//
//  The allowlist, the stagger rules, the cross-file string contract and the
//  one-shot preview: CLAUDE.md § Scroll-reveal animations.
//
//  Frontend runtime: animations.js + animations.css.
// =============================================================

( function () {
    const { addFilter } = wp.hooks;
    const { createElement: el, Fragment, useState, useEffect, useRef } = wp.element;
    const { createHigherOrderComponent } = wp.compose;
    const { useSelect } = wp.data;
    const { BlockControls } = wp.blockEditor;
    const { ToolbarGroup, ToolbarButton, Dropdown, SelectControl, ToggleControl, RangeControl, Button } = wp.components;

    // Static-save blocks only — extraProps classes never reach
    // dynamic (server-rendered) blocks' frontend markup.
    const ALLOWED_BLOCKS = [
        'core/group',
        'core/columns',
        'core/column',
        'core/cover',
        'core/image',
        'core/heading',
        'core/paragraph',
        'core/media-text',
        'core/buttons',
        'core/gallery',
    ];

    // Containers that can stagger their DIRECT children (a subset of
    // ALLOWED_BLOCKS). The toggle tags the parent instead of animating it, and
    // animations.css sequences the children.
    const STAGGER_BLOCKS = [
        'core/group',
        'core/columns',
        'core/buttons',
        'core/gallery',
    ];

    // Friendly noun for the "controlled by parent" note, keyed on the
    // parent's block name.
    const STAGGER_PARENT_LABEL = {
        'core/group':   'group',
        'core/columns': 'columns block',
        'core/buttons': 'buttons block',
        'core/gallery': 'gallery',
    };

    // Popover header logo URL (injected from PHP in animations.php).
    const LOGO = ( window.acornAnimAssets && window.acornAnimAssets.logo ) || '';

    // Repeated literals, hoisted so JS / CSS can't silently drift.
    const REDUCED_MOTION_QUERY = '(prefers-reduced-motion: reduce)';
    const DEFAULT_DIRECTION    = 'fade-up'; // enabling picks this default direction
    const VAR_DURATION     = '--anim-duration'; // inline CSS vars written to saved markup
    const VAR_DELAY        = '--anim-delay';
    const VAR_STAGGER_STEP = '--anim-stagger-step'; // stagger mode: delay step between children
    const DEFAULT_STAGGER_STEP = '.5s'; // seeded when stagger is first enabled (an OFFSET_OPTIONS value)

    // Motion constants for the one-shot preview — must mirror the
    // parent-owned --acorn-anim-* tokens in animations.css (no theme.json).
    const EASING           = 'cubic-bezier(0.22, 1, 0.36, 1)';
    const DISTANCE         = '2rem';
    const DEFAULT_DURATION = '3s'; // also the "Default" speed preset (SPEED_OPTIONS below)

    const DIRECTION_CHOICES = [
        // All directions fade, plus a transform on everything but plain Fade.
        // The LCP warning is general, not per-direction — CLAUDE.md
        // § Scroll-reveal animations.
        { value: 'fade', label: 'Fade' },
        { value: 'fade-up', label: 'Fade up' },
        { value: 'fade-down', label: 'Fade down' },
        { value: 'fade-left', label: 'Fade left' },
        { value: 'fade-right', label: 'Fade right' },
    ];

    // Fixed duration presets → written to --anim-duration.
    const SPEED_OPTIONS = [
        { value: '2s', label: 'Fast' },
        { value: '3s', label: 'Default' },
        { value: '4s', label: 'Slow' },
    ];

    // Start offset (animation-delay after the element is revealed) →
    // written to --anim-delay. "None" clears it (CSS falls back to 0s).
    const OFFSET_OPTIONS = [
        { value: '',   label: 'None' },
        { value: '.25s', label: 'Fast' },
        { value: '.5s', label: 'Default' },
        { value: '1s', label: 'Slow' },
    ];

    // Speed/offset render as snap sliders: the slider position is an
    // index into the options above; `marks` label each stop.
    const SPEED_MARKS  = SPEED_OPTIONS.map( function ( o, i ) { return { value: i, label: o.label }; } );
    const OFFSET_MARKS = OFFSET_OPTIONS.map( function ( o, i ) { return { value: i, label: o.label }; } );

    // Index of a stored value in an options list; fallbackIdx if absent.
    function optionIndex( options, value, fallbackIdx ) {
        for ( let i = 0; i < options.length; i++ ) {
            if ( options[ i ].value === value ) return i;
        }
        return fallbackIdx;
    }

    // A RangeControl that snaps between the labelled option stops. The
    // slider position is an index into `options`; onPick gets the chosen
    // option's stored value. Used for both Speed and Offset.
    function snapSlider( label, options, marks, current, fallbackIdx, onPick ) {
        return el( RangeControl, {
            __nextHasNoMarginBottom: true,
            label: label,
            value: optionIndex( options, current, fallbackIdx ),
            min: 0,
            max: options.length - 1,
            step: 1,
            marks: marks,
            withInputField: false,
            renderTooltipContent: function ( i ) {
                return options[ i ] ? options[ i ].label : '';
            },
            onChange: function ( i ) {
                if ( options[ i ] ) onPick( options[ i ].value );
            },
        } );
    }

    const ICON = el(
        'svg',
        { xmlns: 'http://www.w3.org/2000/svg', viewBox: '0 0 24 24', width: 24, height: 24, 'aria-hidden': true },
        el( 'path', { d: 'M2 7h6v1.5H2V7Zm1 4.25h5v1.5H3v-1.5ZM2 15.5h6V17H2v-1.5Z' } ),
        el( 'path', { d: 'M15 4a8 8 0 1 1 0 16 8 8 0 0 1 0-16Zm0 1.5a6.5 6.5 0 1 0 0 13 6.5 6.5 0 0 0 0-13Z' } )
    );

    // ── Attributes ───────────────────────────────────────────────────────
    addFilter(
        'blocks.registerBlockType',
        'acorn/animations/attributes',
        function ( settings, name ) {
            if ( ALLOWED_BLOCKS.indexOf( name ) === -1 ) return settings;
            const animAttrs = {
                animDirection: { type: 'string', default: '' },
                animDuration:  { type: 'string', default: '' },
                animDelay:     { type: 'string', default: '' },
            };
            if ( STAGGER_BLOCKS.indexOf( name ) !== -1 ) {
                animAttrs.animStagger = { type: 'boolean', default: false };
            }
            return Object.assign( {}, settings, {
                attributes: Object.assign( {}, settings.attributes, animAttrs ),
            } );
        }
    );

    // ── Saved markup ─────────────────────────────────────────────────────
    // These land in the block's SAVED html, which is a trade with a known
    // failure mode — CLAUDE.md § Scroll-reveal animations.
    addFilter(
        'blocks.getSaveContent.extraProps',
        'acorn/animations/save-props',
        function ( props, blockType, attributes ) {
            if ( ALLOWED_BLOCKS.indexOf( blockType.name ) === -1 ) return props;
            if ( ! attributes.animDirection ) return props;

            const stagger = !! attributes.animStagger
                && STAGGER_BLOCKS.indexOf( blockType.name ) !== -1;
            const classes = [ props.className ];
            const style = Object.assign( {}, props.style );

            if ( stagger ) {
                // The container is only the scroll trigger; its direct
                // children animate (sequenced by the CSS). Speed → each
                // child's duration; offset → the step between children.
                classes.push( 'anim-stagger', 'anim-stagger-' + attributes.animDirection );
                if ( attributes.animDuration ) style[ VAR_DURATION ] = attributes.animDuration;
                // Written explicitly (0s when "None") so it never falls
                // back to the token default.
                style[ VAR_STAGGER_STEP ] = attributes.animDelay || '0s';
            } else {
                classes.push( 'anim-' + attributes.animDirection );
                if ( attributes.animDuration ) style[ VAR_DURATION ] = attributes.animDuration;
                if ( attributes.animDelay )    style[ VAR_DELAY ]    = attributes.animDelay;
            }

            props.className = classes.filter( Boolean ).join( ' ' );
            if ( Object.keys( style ).length ) props.style = style;

            return props;
        }
    );

    // ── One-shot preview ─────────────────────────────────────────────────
    // The canvas may be iframed, so look the wrapper up by its
    // block-<clientId> id in the top document first, then any iframes.
    function findBlockNode( clientId ) {
        const id = 'block-' + clientId;
        let node = document.getElementById( id );
        if ( node ) return node;

        const iframes = document.querySelectorAll( 'iframe' );
        for ( let i = 0; i < iframes.length; i++ ) {
            try {
                const doc = iframes[ i ].contentDocument;
                node = doc && doc.getElementById( id );
                if ( node ) return node;
            } catch ( e ) {}
        }
        return null;
    }

    // Mirrors the @keyframes `from` transforms in animations.css.
    function previewTransform( direction, distance ) {
        switch ( direction ) {
            case 'fade-up':    return 'translateY(' + distance + ')';
            case 'fade-down':  return 'translateY(calc(-1 * ' + distance + '))';
            case 'fade-left':  return 'translateX(' + distance + ')';
            case 'fade-right': return 'translateX(calc(-1 * ' + distance + '))';
            default:           return '';
        }
    }

    function playPreview( clientId, direction, duration, delay, stagger ) {
        if ( window.matchMedia && window.matchMedia( REDUCED_MOTION_QUERY ).matches ) return;

        const node = findBlockNode( clientId );
        if ( ! node ) return;

        let ms = parseFloat( duration || DEFAULT_DURATION ) * 1000;
        if ( isNaN( ms ) || ms <= 0 ) ms = 600;

        const from      = { opacity: 0 };
        const to        = { opacity: 1 };
        const transform = previewTransform( direction, DISTANCE );
        if ( transform ) {
            from.transform = transform;
            to.transform   = 'none';
        }

        // Stagger: replay each direct child in turn (index × step). Returns
        // even with no children — animating the whole container in stagger mode
        // is something the frontend never does.
        if ( stagger ) {
            let stepMs = parseFloat( delay ) * 1000;
            if ( isNaN( stepMs ) || stepMs < 0 ) stepMs = 0;
            Array.prototype.forEach.call( node.children || [], function ( child, i ) {
                if ( typeof child.animate !== 'function' ) return;
                try {
                    child.animate( [ from, to ], { duration: ms, delay: i * stepMs, easing: EASING } );
                } catch ( e ) {}
            } );
            return;
        }

        if ( typeof node.animate !== 'function' ) return;
        let delayMs = parseFloat( delay ) * 1000;
        if ( isNaN( delayMs ) || delayMs < 0 ) delayMs = 0;
        try {
            node.animate( [ from, to ], { duration: ms, delay: delayMs, easing: EASING } );
        } catch ( e ) {}
    }

    // ── Toolbar control ──────────────────────────────────────────────────
    const withAnimationControls = createHigherOrderComponent( function ( BlockEdit ) {
        return function ( props ) {
            // Early return only on props.name, which is constant for a block
            // instance, so hook order stays stable. Gating on isSelected would
            // break the rules of hooks.
            if ( ALLOWED_BLOCKS.indexOf( props.name ) === -1 ) {
                return el( BlockEdit, props );
            }

            const { attributes, setAttributes, clientId } = props;
            const canStagger = STAGGER_BLOCKS.indexOf( props.name ) !== -1;
            // Committed values (what's actually saved on the block).
            const direction = attributes.animDirection || '';
            const duration  = attributes.animDuration || '';
            const delay     = attributes.animDelay || '';
            const stagger   = canStagger && !! attributes.animStagger;

            // The parent's block name when it is a staggering container, else
            // null. Read reactively, so toggling stagger on the parent
            // locks/unlocks the child live. Direct parent only, like the CSS.
            const staggerParent = useSelect( function ( select ) {
                const store = select( 'core/block-editor' );
                const rootId = store.getBlockRootClientId( clientId );
                if ( ! rootId ) return null;
                const name = store.getBlockName( rootId );
                if ( STAGGER_BLOCKS.indexOf( name ) === -1 ) return null;
                const attrs = store.getBlockAttributes( rootId );
                return attrs && attrs.animStagger ? name : null;
            }, [ clientId ] );
            const lockedByParent = !! staggerParent;

            // Draft values the popover controls edit; only pushed to the
            // block attributes when "Apply" is clicked.
            const [ draft, setDraft ] = useState( { direction: direction, duration: duration, delay: delay, stagger: stagger } );

            // Resyncs the draft when a different block is selected or the
            // committed values change externally (undo). In-progress edits
            // never touch those, so this cannot clobber them mid-edit.
            useEffect(
                function () {
                    setDraft( { direction: direction, duration: duration, delay: delay, stagger: stagger } );
                },
                [ clientId, direction, duration, delay, stagger ]
            );

            const dirty = draft.direction !== direction
                || draft.duration !== duration
                || draft.delay !== delay
                || draft.stagger !== stagger;

            // Patch a single draft field (direction/duration/delay).
            function setField( key, value ) {
                setDraft( function ( d ) {
                    return Object.assign( {}, d, { [ key ]: value } );
                } );
            }

            function applyChanges() {
                const next = {
                    animDirection: draft.direction,
                    animDuration:  draft.duration,
                    animDelay:     draft.delay,
                };
                if ( canStagger ) next.animStagger = draft.stagger;
                setAttributes( next );
            }

            // Replay the animation once when the committed values change —
            // on Apply, and also on undo/redo (any committed change). Only
            // the initial mount is skipped, so reload/reselect stay static.
            const didMount = useRef( false );
            useEffect(
                function () {
                    if ( ! didMount.current ) {
                        didMount.current = true;
                        return;
                    }
                    if ( ! direction ) return;
                    playPreview( clientId, direction, duration, delay, stagger );
                },
                [ direction, duration, delay, stagger ]
            );

            return el(
                Fragment,
                {},
                el( BlockEdit, props ),
                el(
                    BlockControls,
                    { group: 'other' },
                    el(
                        ToolbarGroup,
                        {},
                        el( Dropdown, {
                            popoverProps: { placement: 'bottom-start' },
                            renderToggle: function ( toggleProps ) {
                                return el( ToolbarButton, {
                                    icon: ICON,
                                    label: 'Animate on scroll',
                                    onClick: toggleProps.onToggle,
                                    'aria-expanded': toggleProps.isOpen,
                                    isPressed: !! direction,
                                } );
                            },
                            renderContent: function () {
                                const enabled = !! draft.direction;
                                const parentLabel = STAGGER_PARENT_LABEL[ staggerParent ] || 'parent block';
                                // Deliberately general: the parent drives this block's
                                // reveal, but a child that is itself a stagger container
                                // is still honoured on the frontend.
                                const noteText = 'This block is a direct child of a ' + parentLabel
                                    + ' that staggers its children, so its reveal is controlled there.'
                                    + ( enabled ? ' Turn off its own animation to keep the markup clean.' : '' );
                                return el(
                                    'div',
                                    { className: 'acorn-anim-popover' },
                                    el(
                                        'div',
                                        { className: 'acorn-anim-header' },
                                        LOGO && el( 'img', {
                                            className: 'acorn-anim-logo',
                                            src: LOGO,
                                            alt: '',
                                            width: 22,
                                            height: 22,
                                        } ),
                                        el( 'span', { className: 'acorn-anim-title' }, 'Acorn Animation' )
                                    ),
                                    lockedByParent && el( 'p', { className: 'acorn-anim-note' }, noteText ),
                                    el( ToggleControl, {
                                        __nextHasNoMarginBottom: true,
                                        label: 'Enable animation',
                                        checked: enabled,
                                        // Locked by a staggering parent: block turning it ON,
                                        // but leave it usable when already on so a stale
                                        // animation can be cleared.
                                        disabled: lockedByParent && ! enabled,
                                        onChange: function ( on ) {
                                            setDraft(
                                                on
                                                    // Default to the transform-based
                                                    // workhorse; hero-safe.
                                                    ? { direction: DEFAULT_DIRECTION, duration: draft.duration, delay: draft.delay, stagger: draft.stagger }
                                                    // Off clears everything → clean markup.
                                                    : { direction: '', duration: '', delay: '', stagger: false }
                                            );
                                        },
                                    } ),
                                    ! lockedByParent && enabled && canStagger && el( ToggleControl, {
                                        __nextHasNoMarginBottom: true,
                                        label: 'Stagger children',
                                        help: 'Animate each direct child in turn — Speed sets each child\'s animation, Offset the delay between them.',
                                        checked: draft.stagger,
                                        onChange: function ( on ) {
                                            setDraft( function ( d ) {
                                                // Seed a visible step the first time
                                                // stagger is turned on with no offset.
                                                const nextDelay = on && ! d.delay ? DEFAULT_STAGGER_STEP : d.delay;
                                                return Object.assign( {}, d, { stagger: on, delay: nextDelay } );
                                            } );
                                        },
                                    } ),
                                    ! lockedByParent && enabled && el( SelectControl, {
                                        __nextHasNoMarginBottom: true,
                                        label: 'Animation',
                                        value: draft.direction,
                                        options: DIRECTION_CHOICES,
                                        // Any reveal keeps the element hidden until it plays,
                                        // so all directions delay LCP on the hero equally.
                                        help: 'Avoid on your hero\'s largest element — it delays largest paint.',
                                        onChange: function ( value ) {
                                            setField( 'direction', value );
                                        },
                                    } ),
                                    ! lockedByParent && enabled && snapSlider(
                                        'Speed', SPEED_OPTIONS, SPEED_MARKS, draft.duration, 1,
                                        function ( value ) { setField( 'duration', value ); }
                                    ),
                                    ! lockedByParent && enabled && snapSlider(
                                        draft.stagger ? 'Offset (stagger step)' : 'Offset (start delay)',
                                        OFFSET_OPTIONS, OFFSET_MARKS, draft.delay, 0,
                                        function ( value ) { setField( 'delay', value ); }
                                    ),
                                    el(
                                        'div',
                                        { className: 'acorn-anim-apply' },
                                        el(
                                            Button,
                                            {
                                                variant: 'primary',
                                                disabled: ! dirty,
                                                onClick: applyChanges,
                                            },
                                            'Apply'
                                        )
                                    )
                                );
                            },
                        } )
                    )
                )
            );
        };
    }, 'withAnimationControls' );

    addFilter( 'editor.BlockEdit', 'acorn/animations/toolbar', withAnimationControls );
} )();
