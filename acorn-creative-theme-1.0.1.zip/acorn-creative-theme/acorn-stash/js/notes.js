// =============================================================
//  NOTES — resolve / reopen from the list
// =============================================================
//  Companion to [acorn_notes] (acorn-stash/php/shortcodes/notes.php).
//
//  Resolving writes the comment status and the audit child note — steps 1 and 2
//  of the editor's own three. Step 3, stripping the inline <mark>, needs the
//  editor open, and skipping it is harmless.
//
//  Row state lives in ONE place: the <li>'s is-open / is-resolved class. Both
//  labels are already in the DOM and CSS picks which shows, so this file holds
//  no markup and no translatable string beyond the error message handed to it.
//
//  Permissions, the data model and why deleting removes replies by hand:
//  CLAUDE.md § Notes.
// =============================================================

( function () {
    const config = window.acornNotes;

    if ( ! config || ! config.root ) {
        return;
    }

    const lists = document.querySelectorAll( '.acorn-notes' );

    if ( ! lists.length ) {
        return;
    }

    // The buttons are hidden until this line runs. Without JS they would be
    // dead controls, and the list reads perfectly well as a read-only punch
    // list — so the enhancement announces itself rather than being assumed.
    lists.forEach( function ( list ) {
        list.classList.add( 'is-ready' );
    } );


    // ============================================
    // REST
    // ============================================

    function request( method, path, body ) {
        const init = {
            method: method,
            credentials: 'same-origin',
            headers: { 'X-WP-Nonce': config.nonce },
        };

        if ( body ) {
            init.headers['Content-Type'] = 'application/json';
            init.body = JSON.stringify( body );
        }

        return fetch( config.root + path, init ).then( function ( response ) {
            if ( ! response.ok ) {
                throw new Error( 'HTTP ' + response.status );
            }

            return response.json();
        } );
    }

    function send( path, body ) {
        return request( 'POST', path, body );
    }


    // ============================================
    // ROW
    // ============================================

    // role="alert" rather than a quiet line: the click looked like it worked
    // — the button went busy and came back — so the failure has to speak.
    function setError( note, message ) {
        let slot = note.querySelector( '.acorn-note-error' );

        if ( ! message ) {
            if ( slot ) {
                slot.remove();
            }

            return;
        }

        if ( ! slot ) {
            slot = document.createElement( 'p' );
            slot.className = 'acorn-note-error is-style-small';
            slot.setAttribute( 'role', 'alert' );
            note.querySelector( '.acorn-note-foot' ).append( slot );
        }

        slot.textContent = message;
    }

    async function toggle( note, button ) {
        const id = Number( note.dataset.noteId );
        const postId = Number( note.dataset.notePost );
        const resolving = note.classList.contains( 'is-open' );
        const status = resolving ? 'approved' : 'hold';

        button.disabled = true;
        note.setAttribute( 'aria-busy', 'true' );
        setError( note, '' );

        try {
            // Status first, audit entry second: a failure on the second call
            // leaves a resolved note missing an audit row, rather than an audit
            // row claiming a resolution that never happened.
            await send( 'wp/v2/comments/' + id, { status: status } );

            await send( 'wp/v2/comments', {
                post: postId,
                parent: id,
                type: 'note',
                status: status,
                content: '',
                meta: { _wp_note_status: resolving ? 'resolved' : 'reopen' },
            } );

            note.classList.toggle( 'is-open', ! resolving );
            note.classList.toggle( 'is-resolved', resolving );
        } catch ( error ) {
            setError( note, config.i18n.error );
        } finally {
            button.disabled = false;
            note.removeAttribute( 'aria-busy' );
        }
    }


    // ============================================
    // DELETE
    // ============================================

    // Takes the row out, then the containers it just emptied, so a post whose
    // last note has gone leaves no empty heading. Once the list itself is empty
    // the page reloads — the empty state is PHP's, with three variants.
    function prune( note ) {
        const list = note.closest( '.acorn-notes' );
        const group = note.closest( '.acorn-notes-post' );
        const section = note.closest( '.acorn-notes-type' );

        note.remove();

        if ( group && ! group.querySelector( '.acorn-note' ) ) {
            group.remove();
        }

        if ( section && ! section.querySelector( '.acorn-note' ) ) {
            section.remove();
        }

        if ( list && ! list.querySelector( '.acorn-note' ) ) {
            window.location.reload();
        }
    }

    async function remove( note, button ) {
        if ( ! window.confirm( config.i18n.confirmDelete ) ) {
            return;
        }

        const id = Number( note.dataset.noteId );

        button.disabled = true;
        note.setAttribute( 'aria-busy', 'true' );
        setError( note, '' );

        try {
            // Replies first, and by hand — wp_delete_comment() reparents a
            // deleted comment's children instead of removing them. Read live,
            // not from an attribute: a reply added since load still has to go.
            const replies = await request(
                'GET',
                'wp/v2/comments?per_page=100&_fields=id&type=note&status=all&parent=' + id
            );

            for ( const reply of replies ) {
                await request( 'DELETE', 'wp/v2/comments/' + reply.id + '?force=true' );
            }

            // force=true, not the trash: the row is gone from the list either
            // way, and a trashed note that no screen can reach again is just
            // a leak. The confirmation said delete.
            await request( 'DELETE', 'wp/v2/comments/' + id + '?force=true' );

            prune( note );
        } catch ( error ) {
            setError( note, config.i18n.error );
            button.disabled = false;
            note.removeAttribute( 'aria-busy' );
        }
    }


    // ============================================
    // EVENTS
    // ============================================

    // Delegated, so a row the script never saw — a future filter, a partial
    // re-render — still works without rebinding anything.
    document.addEventListener( 'click', function ( event ) {
        const action = event.target.closest( '.acorn-note-action' );
        const destroy = event.target.closest( '.acorn-note-delete' );
        const note = ( action || destroy ) && event.target.closest( '.acorn-note' );

        if ( ! note ) {
            return;
        }

        if ( action ) {
            toggle( note, action );
        } else {
            remove( note, destroy );
        }
    } );
}() );
