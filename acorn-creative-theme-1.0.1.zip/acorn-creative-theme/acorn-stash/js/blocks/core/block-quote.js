// =============================================================
//  core/quote + core/pullquote — Decorative Icon (editor preview)
// =============================================================
//  If the child theme supplies SVGs in acorn-stash/icons/core/block-quote/,
//  PHP passes them via window.acornBlockQuoteIcons before this script runs.
//
//  Injects CSS custom properties scoped to the <blockquote> so
//  style-editor.css can render the mask-image. Uses a base64 data URL
//  (dataUrl) rather than the file URL to avoid HTTPS/CORS issues in the
//  canvas. Canvas may be in an iframe, so a MutationObserver watches for
//  it — same technique as details.js. Frontend injection: block-quote-icons.php.
//
//  The quote/pullquote edit is fully replaced by quote.js (attribution),
//  which renders no frontend SVG in the canvas — so a masked ::before
//  stands in for the preview. This script only supplies its URL.
// =============================================================

(function () {
    const icons = window.acornBlockQuoteIcons || {};
    if ( ! icons.mark ) return;

    // Scope to the blockquote (editor canvas targets in _block-quote-editor.scss)
    // rather than :root so cascade is predictable and inheritance to ::before works.
    const css = `.wp-block-quote,.wp-block-pullquote blockquote{--block-quote-icon-url:url('${ icons.mark.dataUrl }');--block-quote-icon-display:inline-block;}`;

    function inject( doc ) {
        if ( ! doc || doc.getElementById( 'acorn-block-quote-icon-css' ) ) return;
        const style = doc.createElement( 'style' );
        style.id = 'acorn-block-quote-icon-css';
        style.textContent = css;
        doc.head.appendChild( style );
    }

    function injectIntoIframes() {
        try {
            ( window.parent || window ).document.querySelectorAll( 'iframe' ).forEach( ( f ) => {
                f.contentDocument && inject( f.contentDocument );
            } );
        } catch ( e ) {}
    }

    inject( document );
    injectIntoIframes();

    try {
        new MutationObserver( injectIntoIframes ).observe(
            ( window.parent || window ).document.body,
            { childList: true, subtree: true }
        );
    } catch ( e ) {
        setTimeout( injectIntoIframes, 1500 );
    }
} )();
