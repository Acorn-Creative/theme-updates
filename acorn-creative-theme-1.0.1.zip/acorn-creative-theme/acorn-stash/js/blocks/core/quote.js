// =============================================================
//  core/quote + core/pullquote — Citation Attribution
// =============================================================
//  Repurposes the built-in citation as the AUTHOR field and adds a second
//  in-canvas "Role / title" field, both rendered INSIDE the block. `settings.edit`
//  is REPLACED for both blocks, with plain-JS reproductions of WP 7.0's edit
//  components, because core hardcodes the citation inside its own.
//
//  `save` is untouched, so saved markup and validation are exactly core's.
//
//  The server side, the styling, and the two deliberate regressions that come
//  with reproducing core's edit: CLAUDE.md § `core/quote`.
// =============================================================

( function () {
    const { addFilter } = wp.hooks;
    const { createElement: el, Fragment } = wp.element;
    const {
        RichText,
        BlockControls,
        AlignmentControl,
        useBlockProps,
        useInnerBlocksProps,
    } = wp.blockEditor;
    const { BlockQuotation } = wp.components;
    // wp.data / wp.blocks load transitively via the wp-block-editor dep.
    const { useSelect } = wp.data;

    const QUOTE_TEMPLATE = [ [ 'core/paragraph', {} ] ];

    // Enter at the end of a field escapes into a new paragraph after
    // the block, matching core's citation behavior.
    function splitAtEnd( insertBlocksAfter ) {
        return function () {
            insertBlocksAfter( wp.blocks.createBlock( wp.blocks.getDefaultBlockName() ) );
        };
    }

    // The citation, repurposed as the Author field. Hidden when empty
    // and the block is unselected (same rule as core).
    function citationField( props, showWhenEmpty, blockClassName ) {
        const { attributes, setAttributes, insertBlocksAfter } = props;
        const citation = attributes.citation;

        if ( ! showWhenEmpty && RichText.isEmpty( citation ) ) {
            return null;
        }

        return el( RichText, {
            identifier:  'citation',
            tagName:     'cite',
            style:       { display: 'block' },
            className:   blockClassName,
            value:       citation,
            onChange:    ( v ) => setAttributes( { citation: v } ),
            placeholder: 'Author',
            'aria-label': 'Quote author',
            __unstableMobileNoFocusOnMount: true,
            __unstableOnSplitAtEnd: splitAtEnd( insertBlocksAfter ),
        } );
    }

    // The extra Role / title field. Plain text (no formats); rendered
    // as a div in the editor, re-homed into the <cite> on the frontend
    // by the render_block filter.
    function roleField( props, showWhenEmpty ) {
        const { attributes, setAttributes, insertBlocksAfter } = props;
        const role = attributes.role || '';

        if ( ! showWhenEmpty && '' === role ) {
            return null;
        }

        return el( RichText, {
            identifier:  'role',
            tagName:     'div',
            className:   'quote-role',
            value:       role,
            onChange:    ( v ) => setAttributes( { role: v } ),
            placeholder: 'Role / title',
            'aria-label': 'Author role or title',
            allowedFormats: [],
            withoutInteractiveFormatting: true,
            __unstableMobileNoFocusOnMount: true,
            __unstableOnSplitAtEnd: splitAtEnd( insertBlocksAfter ),
        } );
    }

    function alignmentToolbar( attributes, setAttributes ) {
        return el(
            BlockControls,
            { group: 'block' },
            el( AlignmentControl, {
                value:    attributes.textAlign,
                onChange: ( next ) => setAttributes( { textAlign: next } ),
            } )
        );
    }

    // ── core/quote ───────────────────────────────────────────────────────
    function QuoteEdit( props ) {
        const { attributes, setAttributes, clientId, className } = props;
        const { textAlign, allowedBlocks } = attributes;

        // The quote's content is inner blocks, so "selected" must include
        // a selected child — otherwise the fields vanish mid-edit.
        const hasSelection = useSelect(
            ( select ) => {
                const store = select( 'core/block-editor' );
                return (
                    store.isBlockSelected( clientId ) ||
                    store.hasSelectedInnerBlock( clientId )
                );
            },
            [ clientId ]
        );

        let cls = className || '';
        if ( textAlign ) {
            cls = ( cls ? cls + ' ' : '' ) + 'has-text-align-' + textAlign;
        }

        // Block props go on the <blockquote>, inner-blocks props on the inner
        // <div class="quote-content"> — mirroring the render_block wrapper in
        // quote-attribution.php. The class is a cross-file contract string.
        const blockProps      = useBlockProps( { className: cls } );
        const innerBlocksProps = useInnerBlocksProps( { className: 'quote-content' }, {
            template: QUOTE_TEMPLATE,
            templateInsertUpdatesSelection: true,
            __experimentalCaptureToolbars: true,
            renderAppender: false,
            allowedBlocks: allowedBlocks,
        } );

        const contentProps = Object.assign( {}, innerBlocksProps );
        delete contentProps.children;

        return el(
            Fragment,
            {},
            alignmentToolbar( attributes, setAttributes ),
            el(
                BlockQuotation,
                blockProps,
                el(
                    'div',
                    contentProps,
                    innerBlocksProps.children,
                    citationField( props, hasSelection, 'wp-block-quote__citation' ),
                    roleField( props, hasSelection )
                )
            )
        );
    }

    // ── core/pullquote ───────────────────────────────────────────────────
    function PullquoteEdit( props ) {
        const { attributes, setAttributes, isSelected } = props;
        const { textAlign, value } = attributes;

        const blockProps = useBlockProps( {
            className: textAlign ? 'has-text-align-' + textAlign : undefined,
        } );

        return el(
            Fragment,
            {},
            alignmentToolbar( attributes, setAttributes ),
            el(
                'figure',
                blockProps,
                el(
                    'blockquote',
                    {},
                    el(
                        'div',
                        { className: 'quote-content' },
                        el( RichText, {
                            identifier:  'value',
                            tagName:     'p',
                            value:       value,
                            onChange:    ( v ) => setAttributes( { value: v } ),
                            placeholder: 'Add quote',
                            'aria-label': 'Pullquote text',
                        } ),
                        citationField( props, isSelected, 'wp-block-pullquote__citation' ),
                        roleField( props, isSelected )
                    )
                )
            )
        );
    }

    addFilter(
        'blocks.registerBlockType',
        'acorn/quote-attribution',
        function ( settings, name ) {
            if ( 'core/quote' === name ) {
                return Object.assign( {}, settings, { edit: QuoteEdit } );
            }
            if ( 'core/pullquote' === name ) {
                return Object.assign( {}, settings, { edit: PullquoteEdit } );
            }
            return settings;
        }
    );
} )();
