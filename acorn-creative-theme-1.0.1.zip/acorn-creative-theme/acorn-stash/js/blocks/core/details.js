// =============================================================
//  core/details — Block Editor Extension
// =============================================================
//  If the child theme supplies SVGs in acorn-stash/icons/core/details/,
//  PHP passes them via window.acornDetailsIcons before this script runs.
//
//  Injects CSS custom properties scoped to the <summary> element so
//  style-editor.css can render the mask-image. Uses a base64 data URL
//  (dataUrl) rather than the file URL to avoid HTTPS/CORS issues in the
//  canvas. Canvas may be in an iframe, so a MutationObserver watches for
//  it — same technique as accordion.js. Frontend injection: details-icons.php.
// =============================================================

(function () {
    const icons = window.acornDetailsIcons || {};
    if ( ! icons.marker ) return;

    // Scope variables to the summary element (mirrors accordion.js pattern)
    // rather than :root so cascade is predictable and inheritance to ::before works.
    const css = `.wp-block-details summary{--details-icon-url:url('${ icons.marker.dataUrl }');--details-icon-display:inline-block;}`;

    function inject( doc ) {
        if ( ! doc || doc.getElementById( 'acorn-details-icon-css' ) ) return;
        const style = doc.createElement( 'style' );
        style.id = 'acorn-details-icon-css';
        style.textContent = css;
        doc.head.appendChild( style );
    }

    function injectIntoIframes() {
        try {
            ( window.parent || window ).document.querySelectorAll( 'iframe' ).forEach( ( f ) => {
                f.contentDocument && inject( f.contentDocument );
            } );
        } catch ( e ) {}
    }

    inject( document );
    injectIntoIframes();

    try {
        new MutationObserver( injectIntoIframes ).observe(
            ( window.parent || window ).document.body,
            { childList: true, subtree: true }
        );
    } catch ( e ) {
        setTimeout( injectIntoIframes, 1500 );
    }
} )();
