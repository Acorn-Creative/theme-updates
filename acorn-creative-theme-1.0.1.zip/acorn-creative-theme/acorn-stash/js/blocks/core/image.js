// =============================================================
//  core/image — No Auto-Imported Caption
// =============================================================
//  Stops a caption landing on a NEWLY placed image, which is the only clean
//  goal core leaves open — the field then stays inactive by default and
//  everything else behaves normally.
//
//  Two placement paths, so two interceptions:
//   A. the block's own media button — strip it in setAttributes.
//   B. the inserter's Media / Openverse tab — catch it on first render of a
//      just-inserted block, before Caption mounts.
//
//  Why there is no cleaner hook, and what the trade is:
//  CLAUDE.md § `core/image`.
// =============================================================

(function () {
    const { addFilter } = wp.hooks;
    const { createHigherOrderComponent } = wp.compose;
    const { createElement: el, useEffect, useRef } = wp.element;
    const { useSelect } = wp.data;
    const { RichText } = wp.blockEditor;

    const withNoAutoCaption = createHigherOrderComponent((BlockEdit) => {
        return (props) => {
            if (props.name !== 'core/image') {
                return el(BlockEdit, props);
            }

            const { attributes, setAttributes, clientId } = props;

            // Path A — image placed/replaced via the block's media button.
            const setAttributesNoAutoCaption = (next) => {
                if (next && next.url && next.url !== attributes.url && next.caption) {
                    const { caption, ...rest } = next;
                    setAttributes(rest);
                    return;
                }
                setAttributes(next);
            };

            // Path B — image inserted via the inserter Media / Openverse tab,
            // created with a caption already in attributes.
            const justInserted = useSelect(
                (select) => select('core/block-editor').wasBlockJustInserted(clientId),
                [clientId]
            );
            const handled = useRef(false);
            const stripOnInsert =
                justInserted && !handled.current && ! RichText.isEmpty(attributes.caption);

            useEffect(() => {
                if (stripOnInsert) {
                    handled.current = true;
                    setAttributes({ caption: undefined });
                }
            }, [stripOnInsert]); // eslint-disable-line react-hooks/exhaustive-deps

            // On that first render, hand the inner edit an empty caption so
            // core's Caption mounts hidden (avoids the "shown-but-empty" prompt).
            const innerProps = stripOnInsert
                ? {
                      ...props,
                      attributes: { ...attributes, caption: undefined },
                      setAttributes: setAttributesNoAutoCaption,
                  }
                : { ...props, setAttributes: setAttributesNoAutoCaption };

            return el(BlockEdit, innerProps);
        };
    }, 'withNoAutoCaption');

    addFilter('editor.BlockEdit', 'acorn/image-no-auto-caption', withNoAutoCaption);
})();
