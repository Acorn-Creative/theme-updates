// =============================================================
//  core/navigation — Block Editor Extension
// =============================================================
//  PHP passes the child's navigation SVGs via window.acornNavigationIcons,
//  keyed by role: { submenu, open, close }. Each role is independent — only
//  the ones present emit rules. Frontend injection: navigation-icons.php.
//
//  Injects custom properties scoped to each icon's own element, so
//  style-editor.css can mask over core's default SVG. A base64 data URL
//  rather than the file URL, to dodge HTTPS/CORS in the canvas — which may be
//  an iframe, hence the MutationObserver.
// =============================================================

(function () {
    const icons = window.acornNavigationIcons || {};

    // role → the element whose ::before paints the mask. Var names must stay
    // byte-identical to _navigation-editor.scss in the child theme.
    const TARGETS = {
        submenu: '.wp-block-navigation__submenu-icon',
        open:    '.wp-block-navigation__responsive-container-open',
        // Two selectors, comma-joined: core's own close button and WP 7.0's
        // block that replaces it. Interpolated straight in front of `{` below,
        // so a selector LIST works unchanged.
        close:   '.wp-block-navigation__responsive-container-close, .wp-block-navigation-overlay-close',
    };

    const css = Object.keys( TARGETS )
        .filter( ( role ) => icons[ role ] )
        .map( ( role ) =>
            `${ TARGETS[ role ] }{` +
                `--navigation-${ role }-icon-url:url('${ icons[ role ].dataUrl }');` +
                `--navigation-${ role }-icon-display:block;` +
                `--navigation-${ role }-icon-hide:none;` +
            `}`
        )
        .join( '' );

    if ( ! css ) return;

    function inject( doc ) {
        if ( ! doc || doc.getElementById( 'acorn-navigation-icon-css' ) ) return;
        const style = doc.createElement( 'style' );
        style.id = 'acorn-navigation-icon-css';
        style.textContent = css;
        doc.head.appendChild( style );
    }

    function injectIntoIframes() {
        try {
            ( window.parent || window ).document.querySelectorAll( 'iframe' ).forEach( ( f ) => {
                f.contentDocument && inject( f.contentDocument );
            } );
        } catch ( e ) {}
    }

    inject( document );
    injectIntoIframes();

    try {
        new MutationObserver( injectIntoIframes ).observe(
            ( window.parent || window ).document.body,
            { childList: true, subtree: true }
        );
    } catch ( e ) {
        setTimeout( injectIntoIframes, 1500 );
    }
} )();
