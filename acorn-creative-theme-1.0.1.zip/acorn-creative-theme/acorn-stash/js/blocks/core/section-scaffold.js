// =============================================================
//  core/group & core/cover — Section Tag Default
// =============================================================
//  Newly inserted top-level group and cover blocks default to
//  <section> instead of <div>, full width, and named "Section"
//  in the list view. Since tagName is a real block attribute
//  saved into the markup, the frontend renders the tag natively
//  and the editor canvas matches.
//
//  Only applies at insert time, so existing content and explicit
//  HTML element choices (Advanced → HTML element) are never
//  overridden. A just-inserted block that already has a List View
//  name (e.g. a pattern's outer container) is also left untouched.
// =============================================================

(function () {
    const { addFilter } = wp.hooks;
    const { createHigherOrderComponent } = wp.compose;
    const { createElement: el, useEffect } = wp.element;
    const { useSelect, useDispatch } = wp.data;
    const { createBlock } = wp.blocks;

    const TARGETS = ['core/group', 'core/cover'];

    const withSectionDefault = createHigherOrderComponent((BlockEdit) => {
        return (props) => {
            // Only extend group/cover, pass everything else through unchanged
            if (!TARGETS.includes(props.name)) {
                return el(BlockEdit, props);
            }

            const { clientId, attributes, setAttributes } = props;

            const { isTopLevel, justInserted } = useSelect((select) => {
                const blockEditor = select('core/block-editor');
                return {
                    isTopLevel: blockEditor.getBlockRootClientId(clientId) === '',
                    justInserted: blockEditor.wasBlockJustInserted(clientId),
                };
            }, [clientId]);

            const { replaceInnerBlocks } = useDispatch('core/block-editor');

            useEffect(() => {
                // tagName defaults to 'div' via block.json, so a fresh insert
                // reads 'div' — justInserted is what separates a new block
                // from a deliberate <div> choice in saved content.
                const supportsTag = !!wp.blocks.getBlockType(props.name)?.attributes?.tagName;
                // A block that already carries a List View name is authored/intentional
                // (a pattern's outer container, or a deliberately-named block) — leave it
                // entirely alone: don't rename, retag, or scaffold.
                if (!supportsTag || !isTopLevel || !justInserted || attributes.tagName !== 'div' || attributes.metadata?.name) {
                    return;
                }

                setAttributes({
                    tagName: 'section',
                    align: 'full',
                    metadata: { ...(attributes.metadata || {}), name: 'Section' },
                });

                // Scaffold a constrained inner container (group only — cover
                // manages its own inner content area). Note: a group with
                // children skips the Row/Stack/Grid variation picker.
                // Paused for now — no auto content-width container on insert.
                // const isEmpty = wp.data.select('core/block-editor').getBlockCount(clientId) === 0;
                // if (props.name === 'core/group' && isEmpty) {
                //     replaceInnerBlocks(clientId, [
                //         createBlock('core/group', {
                //             layout: { type: 'constrained' },
                //             metadata: { name: 'Content Width Container' },
                //         }),
                //     ], false);
                // }
            }, []); // eslint-disable-line react-hooks/exhaustive-deps

            return el(BlockEdit, props);
        };
    }, 'withSectionDefault');

    addFilter('editor.BlockEdit', 'acorn/section-tag-default', withSectionDefault);
})();
