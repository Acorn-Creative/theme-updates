// =============================================================
//  core/accordion — Block Editor Extension
// =============================================================
//  If the child theme supplies SVGs in acorn-stash/icons/core/accordion/,
//  PHP passes them via window.acornAccordionIcons before this script runs.
//
//  Injects CSS custom properties scoped to the toggle icon element so
//  style-editor.css can render the mask-image. Uses a base64 data URL
//  (dataUrl) rather than the file URL to avoid HTTPS/CORS issues in the
//  canvas. Canvas may be in an iframe, so a MutationObserver watches for
//  it — same technique as link-icons. Frontend injection: accordion-icons.php.
// =============================================================

(function () {
    const icons = window.acornAccordionIcons || {};
    if ( ! icons.toggle ) return;

    // Scope variables to the toggle icon element (mirrors button.js pattern)
    // rather than :root so cascade is predictable and inheritance to ::before works.
    const css = `.wp-block-accordion-heading__toggle-icon{--accordion-toggle-icon-url:url('${ icons.toggle.dataUrl }');--accordion-toggle-icon-display:block;}`;

    function inject( doc ) {
        if ( ! doc || doc.getElementById( 'acorn-accordion-icon-css' ) ) return;
        const style = doc.createElement( 'style' );
        style.id = 'acorn-accordion-icon-css';
        style.textContent = css;
        doc.head.appendChild( style );
    }

    function injectIntoIframes() {
        try {
            ( window.parent || window ).document.querySelectorAll( 'iframe' ).forEach( ( f ) => {
                f.contentDocument && inject( f.contentDocument );
            } );
        } catch ( e ) {}
    }

    inject( document );
    injectIntoIframes();

    try {
        new MutationObserver( injectIntoIframes ).observe(
            ( window.parent || window ).document.body,
            { childList: true, subtree: true }
        );
    } catch ( e ) {
        setTimeout( injectIntoIframes, 1500 );
    }
} )();
