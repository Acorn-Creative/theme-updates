<?php
// =============================================================
//  LINK ICONS
// =============================================================
//  Detects link type from href and injects the matching SVG
//  from the active theme's acorn-stash/icons/site/link/.
//
//  Applies when the <a> or any ancestor within 3 levels has .has-icon.
//
//  Position:
//   - phone, email       → before link text
//   - external, download → after link text
//
//  Frontend: inline SVG via render_block (covers template parts)
//  Editor:   CSS mask-image via child theme SCSS (style-admin.css)
// =============================================================


// ============================================
// HELPERS
// ============================================

function acorn_link_icon_path( string $type ): ?string {
    $path = get_stylesheet_directory() . "/acorn-stash/icons/site/link/{$type}.svg";
    return file_exists( $path ) ? $path : null;
}

function acorn_link_icon_svg( string $type ): ?string {
    static $cache = [];
    if ( ! array_key_exists( $type, $cache ) ) {
        $path          = acorn_link_icon_path( $type );
        $cache[ $type ] = $path ? trim( file_get_contents( $path ) ) : null;
    }
    return $cache[ $type ];
}

function acorn_detect_link_type( string $href ): ?string {
    if ( str_starts_with( $href, 'tel:' ) )    return 'phone';
    if ( str_starts_with( $href, 'mailto:' ) ) return 'email';

    $path = wp_parse_url( $href, PHP_URL_PATH ) ?? '';
    $ext  = strtolower( pathinfo( $path, PATHINFO_EXTENSION ) );
    if ( $ext && in_array( $ext, [ 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'ppt', 'pptx', 'zip', 'rar', 'csv', 'mp3', 'mp4', 'mov' ], true ) ) {
        return 'download';
    }

    if ( preg_match( '/^https?:\/\//i', $href ) ) {
        $site_host = wp_parse_url( home_url(), PHP_URL_HOST );
        $link_host = wp_parse_url( $href, PHP_URL_HOST );
        if ( $link_host && $link_host !== $site_host ) return 'external';
    }

    return null;
}


// ============================================
// FRONTEND: INLINE SVG INJECTION
// ============================================

function acorn_inject_link_icons( string $content ): string {
    // Quick bail — must contain both signals before touching the DOM
    if ( ! str_contains( $content, 'has-icon' ) || ! str_contains( $content, 'href' ) ) {
        return $content;
    }

    $dom = new DOMDocument();
    libxml_use_internal_errors( true );
    $dom->loadHTML(
        '<?xml version="1.0" encoding="UTF-8"?>' .
        '<html><head><meta charset="UTF-8"/></head><body>' .
        '<div id="acorn-wrap">' . $content . '</div>' .
        '</body></html>'
    );
    libxml_clear_errors();

    $wrapper = $dom->getElementById( 'acorn-wrap' );
    if ( ! $wrapper ) return $content;

    $links    = iterator_to_array( $wrapper->getElementsByTagName( 'a' ) );
    $modified = false;

    foreach ( $links as $link ) {
        if ( ! $link instanceof DOMElement ) continue;

        // Skip if SVG already injected (prevents double-injection on nested blocks)
        $existing = $link->getElementsByTagName( 'svg' );
        $already_injected = false;
        foreach ( $existing as $svg ) {
            if ( str_contains( $svg->getAttribute( 'class' ), 'link-icon' ) ) {
                $already_injected = true;
                break;
            }
        }
        if ( $already_injected ) continue;

        // Walk up to 3 ancestor levels looking for .has-icon
        $has_class = false;
        $node      = $link;
        for ( $i = 0; $i <= 3; $i++ ) {
            if ( ! $node instanceof DOMElement ) break;
            if ( preg_match( '/\bhas-icon\b/', $node->getAttribute( 'class' ) ) ) {
                $has_class = true;
                break;
            }
            $node = $node->parentNode;
        }
        if ( ! $has_class ) continue;

        $type = acorn_detect_link_type( $link->getAttribute( 'href' ) );
        if ( ! $type ) continue;

        $svg_string = acorn_link_icon_svg( $type );
        if ( ! $svg_string ) continue;

        $svg_doc = new DOMDocument();
        libxml_use_internal_errors( true );
        $svg_doc->loadXML( $svg_string );
        libxml_clear_errors();
        if ( ! $svg_doc->documentElement ) continue;

        $svg_node = $dom->importNode( $svg_doc->documentElement, true );
        $svg_node->setAttribute( 'aria-hidden', 'true' );
        $svg_node->setAttribute( 'class', trim( $svg_node->getAttribute( 'class' ) . " link-icon link-icon--{$type}" ) );

        if ( in_array( $type, [ 'phone', 'email' ], true ) ) {
            $link->insertBefore( $svg_node, $link->firstChild );
        } else {
            $link->appendChild( $svg_node );
        }

        $modified = true;
    }

    if ( ! $modified ) return $content;

    $output = '';
    foreach ( $wrapper->childNodes as $node ) {
        $output .= $dom->saveHTML( $node );
    }

    return $output;
}

add_filter( 'render_block', 'acorn_inject_link_icons', 20 );


// ============================================
// EDITOR CANVAS: CSS VARIABLE INJECTION
// ============================================

add_action( 'enqueue_block_editor_assets', function () {
    $icons = [];
    $base  = get_stylesheet_directory_uri() . '/acorn-stash/icons/site/link';

    foreach ( [ 'phone', 'email', 'external', 'download' ] as $type ) {
        if ( file_exists( get_stylesheet_directory() . "/acorn-stash/icons/site/link/{$type}.svg" ) ) {
            $icons[ $type ] = "{$base}/{$type}.svg";
        }
    }

    if ( ! $icons ) return;

    $site_url = home_url();
    $js = 'window.acornLinkIcons=' . wp_json_encode( $icons ) . ';';
    $js .= 'window.acornSiteUrl=' . wp_json_encode( $site_url ) . ';';
    $js .= "(function(){
    var icons=window.acornLinkIcons||{};
    var siteUrl=window.acornSiteUrl||'';
    if(!Object.keys(icons).length)return;
    function buildCSS(){
        var vars=Object.keys(icons).map(function(t){
            // external display is scoped per-selector below — not set globally
            if(t==='external')return'--link-icon-'+t+':url(\''+icons[t]+'\')';
            return'--link-icon-'+t+':url(\''+icons[t]+'\');--link-icon-'+t+'-display:inline-block';
        }).join(';');
        var css=':root{'+vars+'}';
        // External: only show on links that don't start with the site URL
        if(icons.external){
            var sel='.has-icon a[href^=\'http\']:not([href^=\''+siteUrl+'\'])::after,'
                   +'a[href^=\'http\']:not([href^=\''+siteUrl+'\']).has-icon::after';
            css+=sel+'{--link-icon-external-display:inline-block}';
        }
        return css;
    }
    function inject(doc){
        if(!doc||doc.getElementById('acorn-link-icon-vars'))return;
        var s=doc.createElement('style');
        s.id='acorn-link-icon-vars';
        s.textContent=buildCSS();
        doc.head.appendChild(s);
    }
    function injectIframes(){
        try{
            var root=(window.parent||window).document;
            root.querySelectorAll('iframe').forEach(function(f){
                f.contentDocument&&inject(f.contentDocument);
            });
        }catch(e){}
    }
    inject(document);
    injectIframes();
    try{
        new MutationObserver(function(){injectIframes();}).observe(
            (window.parent||window).document.body,
            {childList:true,subtree:true}
        );
    }catch(e){setTimeout(injectIframes,1500);}
})();";

    wp_register_script( 'acorn-link-icons-editor', false );
    wp_enqueue_script( 'acorn-link-icons-editor' );
    wp_add_inline_script( 'acorn-link-icons-editor', $js );
} );
