<?php
// =============================================================
//  Self-hosted theme updates via plugin-update-checker (PUC).
//
//  Delivers new parent-theme versions through WordPress's native
//  "Update Available" flow from a metadata JSON published on GitHub
//  Pages — no wordpress.org, no per-site token, no plugin dependency.
//
//  The source repo stays PRIVATE. Only the artifacts are public: the
//  update JSON and the release zips live in the separate public repo
//  Acorn-Creative/theme-updates, served by its Pages site. release.sh
//  commits them there. Anything WordPress downloads unauthenticated is
//  public by definition, so this is the same exposure as any other
//  self-hosted channel.
//
//  PUC is vendored at acorn-stash/lib/plugin-update-checker/. To upgrade
//  it, re-vendor that directory by hand (drop in a newer release).
//
//  The metadata JSON must expose (theme mode): `version` + `details_url`
//  (both required by PUC) and `download_url`. Version is compared with
//  version_compare against the `Version:` header in style.css.
//
//  @package Acorn Creative
// =============================================================

if ( ! defined( 'ABSPATH' ) ) exit;

require_once get_template_directory() . '/acorn-stash/lib/plugin-update-checker/plugin-update-checker.php';

use YahnisElsts\PluginUpdateChecker\v5\PucFactory;

PucFactory::buildUpdateChecker(
    'https://acorn-creative.github.io/theme-updates/acorn-creative-theme.json',
    get_template_directory(),   // dir containing style.css → PUC treats this as a Theme
    'acorn-creative-theme'      // must equal the installed theme directory name
);
