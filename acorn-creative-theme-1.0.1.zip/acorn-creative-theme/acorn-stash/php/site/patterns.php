<?php
// =============================================================
//  BLOCK PATTERN CATEGORIES
// =============================================================
//  Registers the theme's own pattern CATEGORIES. The patterns themselves are
//  auto-registered by WordPress, so this file owns nothing else.
//
//  Category slugs are referenced verbatim in each pattern file's "Categories:"
//  header — keep them byte-identical. CLAUDE.md § Pattern registration.
// =============================================================


add_action( 'init', function () {

    $categories = [
        'acorn-hero'         => 'Acorn — Hero',
        'acorn-features'     => 'Acorn — Features',
        'acorn-cta'          => 'Acorn — Call to Action',
        'acorn-content'      => 'Acorn — Content',
        'acorn-faq'          => 'Acorn — FAQ',
        'acorn-footer-cta'   => 'Acorn — Footer CTA',
        'acorn-overlap'      => 'Acorn — Overlap',
    ];

    foreach ( $categories as $slug => $label ) {
        register_block_pattern_category( $slug, [ 'label' => $label ] );
    }

} );


// =============================================================
//  REMOVE CORE PATTERN CATEGORIES
// =============================================================
//  functions.php already disables core's bundled patterns, so these buckets are
//  empty — but WP still lists every registered category in the "create pattern"
//  dropdown. Core registers them on init@10, hence init@20 here.
// =============================================================

add_action( 'init', function () {

    $core_categories = [
        'about', 'audio', 'banner', 'buttons', 'call-to-action', 'columns',
        'contact', 'featured', 'gallery', 'media', 'portfolio', 'posts',
        'query', 'services', 'team', 'testimonials', 'text', 'videos',
    ];

    foreach ( $core_categories as $slug ) {
        unregister_block_pattern_category( $slug );
    }

}, 20 );
