<?php
// =============================================================
//  Login Page
//  Customizes the wp-login.php screen: enqueues the login
//  stylesheet, injects theme.json presets and @font-face rules
//  (WordPress does not auto-emit these here), swaps the logo,
//  and randomizes error messages. Brute force / lockout /
//  enumeration are handled by Solid Security, not this file.
// =============================================================


// ============================================
/// LOGIN PAGE ASSETS
// ============================================
add_action('login_enqueue_scripts', function() {
    $css_path = get_stylesheet_directory() . '/acorn-stash/css/style-login.css';
    if ( file_exists( $css_path ) ) {
        wp_enqueue_style(
            'acorn-creative-login',
            get_stylesheet_directory_uri() . '/acorn-stash/css/style-login.css',
            array(),
            filemtime( $css_path )
        );
    }

    // Inject theme.json CSS variables — the login page runs outside normal theme loading
    // so WordPress does not auto-generate these preset variables here.
    $theme_json_path = get_stylesheet_directory() . '/theme.json';
    if ( file_exists( $theme_json_path ) ) {
        $theme_json    = json_decode( file_get_contents( $theme_json_path ), true );
        $palette       = $theme_json['settings']['color']['palette'] ?? [];
        $radius_sizes  = $theme_json['settings']['border']['radiusSizes'] ?? [];
        $font_families = $theme_json['settings']['typography']['fontFamilies'] ?? [];

        $css_vars = [];
        foreach ( $palette as $color ) {
            $css_vars[] = '--wp--preset--color--' . $color['slug'] . ': ' . $color['color'] . ';';
        }
        foreach ( $font_families as $family ) {
            $css_vars[] = '--wp--preset--font-family--' . $family['slug'] . ': ' . $family['fontFamily'] . ';';
        }

        if ( $css_vars ) {
            // Values come from theme.json; strip angle brackets so a stray
            // "</style>" in a value can't break out of the block.
            $vars = str_replace( [ '<', '>' ], '', implode( ' ', $css_vars ) );
            echo '<style>:root { ' . $vars . ' }</style>';
        }
    }

    // Inject @font-face rules from theme.json — WordPress only emits these on
    // the frontend/admin global styles, not on wp-login.php.
    $families   = wp_get_global_settings( [ 'typography', 'fontFamilies' ] )['theme'] ?? [];
    $font_faces = [];
    foreach ( $families as $family ) {
        // Fall back to the family-level fontFamily — WP can drop the nested one
        // when normalizing theme.json. Strip the fallback stack (after the first
        // comma) and surrounding quotes so we emit just the primary family name.
        $family_name = $family['fontFamily'] ?? '';
        $family_name = trim( explode( ',', $family_name )[0], " '\"" );
        if ( ! $family_name ) continue;

        foreach ( $family['fontFace'] ?? [] as $face ) {
            $srcs = [];
            foreach ( (array) ( $face['src'] ?? [] ) as $src ) {
                if ( str_starts_with( $src, 'file:./' ) ) {
                    $src = get_theme_file_uri( substr( $src, 7 ) );
                }
                $ext    = strtolower( pathinfo( (string) wp_parse_url( $src, PHP_URL_PATH ), PATHINFO_EXTENSION ) );
                $format = [ 'woff2' => 'woff2', 'woff' => 'woff', 'ttf' => 'truetype', 'otf' => 'opentype' ][ $ext ] ?? $ext;
                $srcs[] = sprintf( "url('%s') format('%s')", esc_url( $src ), $format );
            }
            if ( ! $srcs ) continue;

            $rule  = '@font-face {';
            $rule .= "font-family: '" . $family_name . "';";
            $rule .= 'font-style: ' . ( $face['fontStyle'] ?? 'normal' ) . ';';
            $rule .= 'font-weight: ' . ( $face['fontWeight'] ?? '400' ) . ';';
            $rule .= 'font-display: ' . ( $face['fontDisplay'] ?? 'swap' ) . ';';
            $rule .= 'src: ' . implode( ', ', $srcs ) . ';';
            $rule .= '}';
            $font_faces[] = $rule;
        }
    }
    if ( $font_faces ) {
        // Family names / weights come from theme.json; strip angle brackets so a
        // stray "</style>" can't break out of the block.
        $faces = str_replace( [ '<', '>' ], '', implode( '', $font_faces ) );
        echo '<style>' . $faces . '</style>';
    }
});

// Point the logo link back to the site homepage
add_filter('login_headerurl', function() {
    return home_url();
});

// Replace the link text with the site logo — inline SVG when the upload is an SVG
// (so CSS can target paths/fills), otherwise an <img> tag. WordPress outputs the
// return value as raw HTML inside the #login h1 <a>, so we escape attributes only.
add_filter('login_headertext', function($text) {
    $logo_id = get_theme_mod('custom_logo');
    if ( ! $logo_id ) return get_bloginfo('name');

    $file = get_attached_file( $logo_id );
    $ext  = $file ? strtolower( pathinfo( $file, PATHINFO_EXTENSION ) ) : '';

    if ( 'svg' === $ext && is_readable( $file ) ) {
        $svg = file_get_contents( $file );
        // Strip XML declaration / doctype so the SVG embeds cleanly in HTML
        $svg = preg_replace( '/<\?xml.*?\?>|<!DOCTYPE[^>]+>/i', '', $svg );
        // This is echoed raw on the unauthenticated login page, so an uploaded
        // SVG carrying <script>/on*=/foreignObject would be stored XSS. wp_kses
        // drops anything outside the allowlist below.
        $svg = wp_kses( $svg, acorn_login_svg_allowed_tags() );
        if ( trim( $svg ) ) return $svg;
    }

    $url = wp_get_attachment_image_url( $logo_id, 'full' );
    if ( $url ) {
        return sprintf( '<img src="%s" alt="%s">', esc_url( $url ), esc_attr( get_bloginfo( 'name' ) ) );
    }

    return get_bloginfo('name');
});


// wp_kses allowlist for inlined logo SVGs. Presentational elements/attributes
// only — no <script>, <foreignObject>, <use>, event handlers, or href targets,
// which are the SVG XSS vectors. Attribute keys must be lowercase for wp_kses.
function acorn_login_svg_allowed_tags() {
    $common = [
        'class' => true, 'id' => true, 'style' => true, 'fill' => true,
        'fill-opacity' => true, 'fill-rule' => true, 'clip-rule' => true,
        'stroke' => true, 'stroke-width' => true, 'stroke-linecap' => true,
        'stroke-linejoin' => true, 'stroke-opacity' => true, 'stroke-dasharray' => true,
        'opacity' => true, 'transform' => true, 'clip-path' => true,
        'x' => true, 'y' => true, 'width' => true, 'height' => true,
    ];
    return [
        'svg' => array_merge( $common, [
            'xmlns' => true, 'viewbox' => true, 'preserveaspectratio' => true,
            'role' => true, 'aria-hidden' => true, 'aria-label' => true,
            'focusable' => true, 'version' => true,
        ] ),
        'g'        => $common,
        'defs'     => $common,
        'clippath' => $common,
        'title'    => [],
        'desc'     => [],
        'path'     => array_merge( $common, [ 'd' => true ] ),
        'rect'     => array_merge( $common, [ 'rx' => true, 'ry' => true ] ),
        'circle'   => array_merge( $common, [ 'cx' => true, 'cy' => true, 'r' => true ] ),
        'ellipse'  => array_merge( $common, [ 'cx' => true, 'cy' => true, 'rx' => true, 'ry' => true ] ),
        'line'     => array_merge( $common, [ 'x1' => true, 'y1' => true, 'x2' => true, 'y2' => true ] ),
        'polyline' => array_merge( $common, [ 'points' => true ] ),
        'polygon'  => array_merge( $common, [ 'points' => true ] ),
        'lineargradient' => array_merge( $common, [ 'x1' => true, 'y1' => true, 'x2' => true, 'y2' => true, 'gradientunits' => true, 'gradienttransform' => true ] ),
        'radialgradient' => array_merge( $common, [ 'cx' => true, 'cy' => true, 'r' => true, 'fx' => true, 'fy' => true, 'gradientunits' => true, 'gradienttransform' => true ] ),
        'stop'     => array_merge( $common, [ 'offset' => true, 'stop-color' => true, 'stop-opacity' => true ] ),
    ];
}


// ============================================
/// LOGIN ERROR MESSAGES
// ============================================
// Replaces login errors with randomized messages, picked by context.
// Brute force protection, lockouts, and enumeration prevention are
// handled by the security plugin (Solid Security) — not the theme.
add_filter('login_errors', function($error) {
    global $errors;
    $codes = is_wp_error($errors) ? $errors->get_error_codes() : [];

    $bad_credentials = [
        'Hmm, the door stays shut. Give it another go?',
        'That combo didn\'t unlock anything. Jiggle the handle and try again.',
        'Beep boop. The computer found no match.',
        'The squirrels checked the vault twice — no luck.',
        'So close! Probably. We honestly can\'t say. Try again?',
        'The password is wrong. Or the username. We\'re not saying which.',
        'Our magic 8-ball says: try again.',
        'That key fits a different door. Maybe a typo snuck in?',
        'The hamsters spun the wheel and came up empty.',
        'You shall not pass. (Yet! Try again.)',
    ];

    $empty_fields = [
        'The login form works better with words in it.',
        'Invisible ink doesn\'t work here — type something!',
        'A wild empty field appeared!',
        'Both boxes would love some letters.',
        'The squirrels found nothing to deliver.',
    ];

    $lost_password = [
        'We looked under every acorn — no account by that name.',
        'That username isn\'t in our burrow. Try another spelling?',
        'The squirrels searched the archives and came back empty-pawed.',
        'No match found. Maybe a typo snuck in?',
    ];

    if ( array_intersect( $codes, ['invalid_username', 'incorrect_password', 'invalid_email'] ) ) {
        return $bad_credentials[ array_rand($bad_credentials) ];
    }
    if ( array_intersect( $codes, ['empty_username', 'empty_password'] ) ) {
        return $empty_fields[ array_rand($empty_fields) ];
    }
    if ( in_array( 'invalidcombo', $codes, true ) ) {
        return $lost_password[ array_rand($lost_password) ];
    }

    // Anything else (expired reset keys, etc.) passes through unchanged
    return $error;
});
