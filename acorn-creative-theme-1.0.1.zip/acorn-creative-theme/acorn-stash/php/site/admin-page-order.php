<?php
// =============================================================
//  ADMIN PAGES LIST — PIN THE DOCS TREE LAST
// =============================================================
//  Keeps the "Acorn Documentation" page and its children at the bottom of
//  Dashboard → Pages, so a client's real pages sit at the top.
//
//  A CASE flag PREPENDED to ORDER BY, resolved by slug at request time on
//  load-edit.php. The slug list is filterable through
//  `acorn_admin_trailing_pages` — CLAUDE.md § Dashboard → Pages.
// =============================================================


// Top-level slugs whose subtree sorts last, resolved to post IDs.
// Any depth of descendant is included; a missing slug is skipped.
function acorn_admin_trailing_page_ids() {

    $slugs = apply_filters( 'acorn_admin_trailing_pages', [ 'acorn-documentation' ] );

    $statuses = [ 'publish', 'future', 'draft', 'pending', 'private' ];
    $ids      = [];

    foreach ( (array) $slugs as $slug ) {

        $root = get_page_by_path( $slug );

        if ( ! $root ) {
            continue;
        }

        $ids[] = (int) $root->ID;

        $descendants = get_pages( [
            'child_of'    => $root->ID,
            'post_status' => $statuses,
        ] );

        foreach ( $descendants ?: [] as $descendant ) {
            $ids[] = (int) $descendant->ID;
        }
    }

    return array_values( array_unique( $ids ) );
}


add_action( 'load-edit.php', function () {

    if ( 'page' !== ( $_GET['post_type'] ?? 'post' ) ) {
        return;
    }

    $ids = acorn_admin_trailing_page_ids();

    if ( ! $ids ) {
        return;
    }

    add_filter( 'posts_orderby', function ( $orderby, $query ) use ( $ids ) {

        if ( ! $query->is_main_query() || 'page' !== $query->get( 'post_type' ) ) {
            return $orderby;
        }

        global $wpdb;

        // $ids are cast to int in acorn_admin_trailing_page_ids().
        $last = sprintf(
            "CASE WHEN {$wpdb->posts}.ID IN (%s) THEN 1 ELSE 0 END ASC",
            implode( ',', $ids )
        );

        return $orderby ? "{$last}, {$orderby}" : $last;

    }, 10, 2 );

} );
