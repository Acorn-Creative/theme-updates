<?php
// =============================================================
//  NOTES
// =============================================================
//  [acorn_notes] — editorial punch list. Lists the notes left in the block
//  editor, grouped by post type (pages first, then posts, then the rest) and by
//  post, in document order inside a post. Headings are h2 (type) / h3 (post),
//  and the markup is class-hooked for the child to style.
//
//  Attributes:
//    status  open (default) | resolved | all
//    limit   max note threads queried (default 200)
//
//  Data model, permissions and the WP quirks this leans on: CLAUDE.md § Notes.
// =============================================================


// ============================================
// DATA
// ============================================

//  Top-level note threads, newest last. Returns [] when notes have
//  never been used on the site.
function acorn_notes_query( string $status, int $limit ): array {
    $comments = get_comments( [
        'type'    => 'note',
        'parent'  => 0,
        'status'  => $status,
        'number'  => $limit,
        'orderby' => 'comment_date_gmt',
        'order'   => 'ASC',
    ] );

    return is_array( $comments ) ? $comments : [];
}

//  Real reply counts keyed by parent note ID. The resolve/reopen audit
//  entries are empty-content notes, so they are filtered out here.
function acorn_notes_reply_counts( array $note_ids ): array {
    if ( ! $note_ids ) {
        return [];
    }

    $replies = get_comments( [
        'type'       => 'note',
        'parent__in' => $note_ids,
        'status'     => 'all',
        'number'     => 0,
    ] );

    $counts = [];

    foreach ( (array) $replies as $reply ) {
        if ( '' === trim( (string) $reply->comment_content ) ) {
            continue;
        }

        $parent = (int) $reply->comment_parent;
        $counts[ $parent ] = ( $counts[ $parent ] ?? 0 ) + 1;
    }

    return $counts;
}

//  Where each note sits in a post, as [ note_id => [ 'label', 'section',
//  'excerpt', 'text', 'order' ] ]: the nearest heading above the block, the
//  block's own words, an inline note's marked run, and document position.
function acorn_notes_block_map( int $post_id ): array {
    $post = get_post( $post_id );

    if ( ! $post || '' === $post->post_content ) {
        return [];
    }

    $map     = [];
    $index   = 0;
    $section = '';

    $walk = function ( array $blocks ) use ( &$walk, &$map, &$index, &$section ): void {
        foreach ( $blocks as $block ) {
            $name     = (string) ( $block['blockName'] ?? '' );
            $note_ids = $block['attrs']['metadata']['noteId'] ?? null;
            $ids      = array_filter( array_map( 'intval', (array) $note_ids ) );

            if ( $ids ) {
                $label   = acorn_notes_block_label( $name );
                $excerpt = acorn_notes_block_text( $block );

                foreach ( $ids as $note_id ) {
                    $map[ $note_id ] = [
                        'label'   => $label,
                        'section' => $section,
                        'excerpt' => $excerpt,
                        'text'    => '',
                        'order'   => $index,
                    ];
                }

                foreach ( acorn_notes_inline_markers( (string) ( $block['innerHTML'] ?? '' ) ) as $note_id => $text ) {
                    if ( isset( $map[ $note_id ] ) ) {
                        $map[ $note_id ]['text'] = $text;
                    }
                }
            }

            // After the notes on this block, not before — a note on a heading
            // belongs under the heading above it, not under itself.
            if ( 'core/heading' === $name ) {
                $section = acorn_notes_block_text( $block );
            }

            ++$index;

            if ( ! empty( $block['innerBlocks'] ) ) {
                $walk( $block['innerBlocks'] );
            }
        }
    };

    $walk( parse_blocks( $post->post_content ) );

    return $map;
}

//  The block's own words — "Paragraph" names a type, the first line of that
//  paragraph names the block. Falls back through descendants (a container's
//  innerHTML is wrapper markup only), then attrs, then acorn_notes_media_text.
function acorn_notes_block_text( array $block ): string {
    $text = trim( preg_replace( '/\s+/', ' ', wp_strip_all_tags( (string) ( $block['innerHTML'] ?? '' ) ) ) );

    if ( '' !== $text ) {
        return $text;
    }

    foreach ( (array) ( $block['innerBlocks'] ?? [] ) as $inner ) {
        $text = acorn_notes_block_text( (array) $inner );

        if ( '' !== $text ) {
            return $text;
        }
    }

    $attrs = (array) ( $block['attrs'] ?? [] );

    foreach ( [ 'alt', 'caption', 'label', 'title', 'content' ] as $key ) {
        $value = trim( wp_strip_all_tags( (string) ( $attrs[ $key ] ?? '' ) ) );

        if ( '' !== $value ) {
            return $value;
        }
    }

    return acorn_notes_media_text( (string) ( $block['innerHTML'] ?? '' ) );
}

//  Media blocks declare url/alt/caption as `"source": "attribute"`, so
//  parse_blocks() leaves the attrs blank — read them off the markup instead.
//  Alt first, then the filename; a caption is innerHTML and already found.
function acorn_notes_media_text( string $html ): string {
    if ( '' === $html ) {
        return '';
    }

    if ( preg_match( '#\balt=(["\'])(.*?)\1#is', $html, $match ) ) {
        $alt = trim( wp_strip_all_tags( $match[2] ) );

        if ( '' !== $alt ) {
            return $alt;
        }
    }

    if ( preg_match( '#\b(?:src|href)=(["\'])(.*?)\1#is', $html, $match ) ) {
        $path = wp_parse_url( $match[2], PHP_URL_PATH );

        if ( $path ) {
            return basename( $path );
        }
    }

    return '';
}

//  Quote marks inside a quote. Every excerpt is wrapped in “ ”, so a double
//  quote in the page's own copy collides with it. Demote the inner ones to
//  single curly quotes, alternating open and close.
function acorn_notes_nest_quotes( string $text ): string {
    $text = str_replace( [ '“', '”' ], '"', $text );

    if ( false === strpos( $text, '"' ) ) {
        return $text;
    }

    $open = true;

    return preg_replace_callback(
        '#"#',
        function () use ( &$open ) {
            $mark = $open ? '‘' : '’';
            $open = ! $open;

            return $mark;
        },
        $text
    );
}

//  Human name for a block — core's registered title ('Paragraph'), falling
//  back to the slug for a block whose plugin is not active here.
function acorn_notes_block_label( string $block_name ): string {
    if ( '' === $block_name ) {
        return '';
    }

    $type = WP_Block_Type_Registry::get_instance()->get_registered( $block_name );

    if ( $type && $type->title ) {
        return $type->title;
    }

    $slug = substr( $block_name, strpos( $block_name, '/' ) + 1 );

    return ucwords( str_replace( '-', ' ', $slug ) );
}

//  [ note_id => marked text ] for the inline note markers in one block's
//  HTML. data-id is core's marker attribute; the wp-note class check keeps
//  an unrelated <mark> (a text highlight) out of the results.
function acorn_notes_inline_markers( string $html ): array {
    if ( false === strpos( $html, 'wp-note' ) ) {
        return [];
    }

    if ( ! preg_match_all( '#<mark\b([^>]*)>(.*?)</mark>#is', $html, $matches, PREG_SET_ORDER ) ) {
        return [];
    }

    $found = [];

    foreach ( $matches as $match ) {
        if ( false === strpos( $match[1], 'wp-note' ) ) {
            continue;
        }

        if ( ! preg_match( '#data-id=["\']?(\d+)#', $match[1], $id ) ) {
            continue;
        }

        $found[ (int) $id[1] ] = trim( wp_strip_all_tags( $match[2] ) );
    }

    return $found;
}

//  Groups notes as [ post_type => [ post_id => WP_Comment[] ] ], post types in
//  display order and posts sorted by title. Drops notes whose post is gone, or
//  whose post the current user cannot edit.
function acorn_notes_group( array $notes ): array {
    $post_ids = array_unique( array_map( fn( $note ) => (int) $note->comment_post_ID, $notes ) );

    if ( $post_ids ) {
        _prime_post_caches( $post_ids );
    }

    $grouped = [];

    foreach ( $notes as $note ) {
        $post = get_post( (int) $note->comment_post_ID );

        if ( ! $post || ! current_user_can( 'edit_post', $post->ID ) ) {
            continue;
        }

        $grouped[ $post->post_type ][ $post->ID ][] = $note;
    }

    // Pages first, then posts, then any other type by its LABEL — the label is
    // what the heading shows, and a slug like `acme_case_study` would file
    // "Case Studies" under A.
    uksort(
        $grouped,
        function ( $a, $b ) {
            $rank   = [ 'page' => 0, 'post' => 1 ];
            $a_rank = $rank[ $a ] ?? 2;
            $b_rank = $rank[ $b ] ?? 2;

            if ( $a_rank !== $b_rank ) {
                return $a_rank - $b_rank;
            }

            return strnatcasecmp( acorn_notes_type_label( $a ), acorn_notes_type_label( $b ) );
        }
    );

    foreach ( $grouped as $post_type => $posts ) {
        uksort(
            $posts,
            fn( $a, $b ) => strnatcasecmp(
                (string) get_post( $a )->post_title,
                (string) get_post( $b )->post_title
            )
        );

        $grouped[ $post_type ] = $posts;
    }

    return $grouped;
}


// ============================================
// TEMPLATE
// ============================================

//  A post type's registered plural label, falling back to the slug: notes
//  outlive the CPT that carried them, so the slug may be all that is left.
function acorn_notes_type_label( string $post_type ): string {
    $object = get_post_type_object( $post_type );

    return ( $object && $object->labels->name ) ? $object->labels->name : $post_type;
}

function acorn_notes_render_note( WP_Comment $note, int $reply_count, array $context = [] ): string {
    $is_resolved = ( '1' === (string) $note->comment_approved );

    // The exact marked run for an inline note, otherwise the block's own
    // opening words. Different things — one is what the note is attached
    // to, the other is only orientation — so they carry different classes.
    $is_inline  = ! empty( $context['text'] );
    $quote      = '';
    $quote_kind = '';

    if ( $is_inline ) {
        $quote      = $context['text'];
        $quote_kind = 'is-anchor';
    } elseif ( ! empty( $context['excerpt'] ) ) {
        $quote      = $context['excerpt'];
        $quote_kind = 'is-excerpt';
    }

    // The address — section, then block type — on its own line. Both blank when
    // the block, or its noteId, is gone.
    $where = array_map( 'esc_html', array_filter( [ $context['section'] ?? '', $context['label'] ?? '' ] ) );

    // An inline note is attached to a run of text, not to the block. Says in
    // words what the highlight on the quote says visually, in the same tint.
    if ( $is_inline ) {
        $where[] = sprintf(
            '<span class="acorn-note-flag">%s</span>',
            esc_html__( 'Inline', 'acorn-creative' )
        );
    }

    $where_markup = $where
        ? sprintf( '<p class="acorn-note-where is-style-small">%s</p>', implode( ' · ', $where ) )
        : '';

    $quote_markup = '';

    if ( '' !== $quote ) {
        // The child truncates the visible line to one row, so the full text
        // goes on the title — the tail of a long quote is a hover away
        // rather than gone.
        $full = $quote;

        // Trim first, then fix the nesting — trimming after would leave the
        // ellipsis sitting outside a quote mark it had just re-opened.
        $quote = acorn_notes_nest_quotes( wp_html_excerpt( $quote, 90, '…' ) );

        $quote_markup = sprintf(
            '<p class="acorn-note-quote %1$s is-style-small" title="%2$s">“%3$s”</p>',
            esc_attr( $quote_kind ),
            esc_attr( $full ),
            esc_html( $quote )
        );
    }

    // Both labels ship and the child shows the one the row's class calls for, so
    // the script flips one class and holds no markup or translated string. Hidden
    // until notes.js adds .is-ready, so neither control is ever dead.
    $controls = '';

    if ( current_user_can( 'edit_comment', (int) $note->comment_ID ) ) {
        $controls = sprintf(
            '<button type="button" class="acorn-note-action">'
                . '<span class="acorn-note-action-resolve">%1$s</span>'
                . '<span class="acorn-note-action-reopen">%2$s'
                    . '<span class="acorn-note-action-undo">%3$s</span>'
                . '</span>'
            . '</button>'
            . '<span class="acorn-note-sep" aria-hidden="true">|</span>'
            . '<button type="button" class="acorn-note-delete">%4$s</button>',
            esc_html__( 'Resolve', 'acorn-creative' ),
            esc_html__( 'Resolved', 'acorn-creative' ),
            esc_html__( 'Select to reopen.', 'acorn-creative' ),
            esc_html__( 'Delete', 'acorn-creative' )
        );
    }

    // Author and date are deliberately absent — a to-do, not an audit log; both
    // are one click away in the editor's Notes panel. Only the parts that apply
    // are emitted, so the child's separator rule never strands a mark.
    $meta = '';

    if ( $reply_count ) {
        /* translators: %d: number of replies on a note. */
        $replies = sprintf( _n( '%d reply', '%d replies', $reply_count, 'acorn-creative' ), $reply_count );
        $meta   .= sprintf( '<span class="acorn-note-replies">%s</span>', esc_html( $replies ) );
    }

    // The fallback for a list notes.js never reached — the child hides it once
    // the script runs, because the control's own label says it then.
    if ( $is_resolved ) {
        $meta .= sprintf(
            '<span class="acorn-note-state">%s</span>',
            esc_html__( 'Resolved', 'acorn-creative' )
        );
    }

    $meta_markup = $meta
        ? sprintf( '<p class="acorn-note-meta is-style-small">%s</p>', $meta )
        : '';

    $foot_markup = sprintf( '<div class="acorn-note-foot">%1$s%2$s</div>', $controls, $meta_markup );

    // Two columns: the context — address over quote, one unit — and the note
    // beside it, with the foot under both. The two data attributes are the whole
    // contract with notes.js: the note to act on and the post it hangs off.
    return sprintf(
        '<li class="acorn-note %1$s" data-note-id="%2$d" data-note-post="%3$d">'
            . '<div class="acorn-note-body">'
                . '<div class="acorn-note-context">%4$s%5$s</div>'
                . '<div class="acorn-note-content">%6$s</div>'
            . '</div>'
            . '%7$s'
        . '</li>',
        trim( ( $is_resolved ? 'is-resolved' : 'is-open' ) . ( $is_inline ? ' is-inline' : '' ) ),
        (int) $note->comment_ID,
        (int) $note->comment_post_ID,
        $where_markup,
        $quote_markup,
        wp_kses_post( wpautop( $note->comment_content ) ),
        $foot_markup
    );
}

function acorn_notes_render_post( int $post_id, array $notes, array $reply_counts ): string {
    // The raw post_title, not get_the_title(), and the slug before giving up —
    // CLAUDE.md § Notes.
    $post  = get_post( $post_id );
    $title = '';

    if ( $post ) {
        $title = '' !== $post->post_title ? $post->post_title : $post->post_name;
    }

    if ( '' === $title ) {
        $title = __( '(no title)', 'acorn-creative' );
    }

    $heading = sprintf( '<span class="acorn-notes-post-name">%s</span>', esc_html( $title ) );

    // The path, not the bare slug — a child page or CPT archive prefix is what
    // makes the page findable. Only for a viewable type: get_permalink() answers
    // for any post type, so a template or non-public CPT would get a link that 404s.
    $permalink = ( $post && is_post_type_viewable( $post->post_type ) ) ? get_permalink( $post_id ) : '';

    if ( $permalink ) {
        $heading .= sprintf(
            ' <a class="acorn-notes-post-slug" href="%s">%s</a>',
            esc_url( $permalink ),
            esc_html( wp_make_link_relative( $permalink ) )
        );
    }

    // Core resolves this per post type — post.php for an ordinary post or
    // CPT, site-editor.php for a template, template part, or navigation —
    // and returns null when the type has no UI or the user can't edit it.
    $edit_link = get_edit_post_link( $post_id );

    if ( $edit_link ) {
        $heading .= sprintf(
            ' <a class="acorn-notes-post-edit" href="%s">%s</a>',
            esc_url( $edit_link ),
            esc_html__( 'Edit', 'acorn-creative' )
        );
    }

    // Document order, the way the editor's Notes panel lists them; a note
    // whose block is gone keeps its date position at the end.
    $blocks = acorn_notes_block_map( $post_id );

    usort(
        $notes,
        fn( $a, $b ) => ( $blocks[ (int) $a->comment_ID ]['order'] ?? PHP_INT_MAX )
            <=> ( $blocks[ (int) $b->comment_ID ]['order'] ?? PHP_INT_MAX )
    );

    $items = '';

    foreach ( $notes as $note ) {
        $note_id = (int) $note->comment_ID;
        $items  .= acorn_notes_render_note(
            $note,
            $reply_counts[ $note_id ] ?? 0,
            $blocks[ $note_id ] ?? []
        );
    }

    return sprintf(
        '<div class="acorn-notes-post">'
            . '<h3 class="acorn-notes-post-title is-style-h5">%1$s</h3>'
            . '<ul class="acorn-notes-list">%2$s</ul>'
        . '</div>',
        $heading,
        $items
    );
}

function acorn_notes_render_type( string $post_type, array $posts, array $reply_counts ): string {
    $label = acorn_notes_type_label( $post_type );

    $body = '';

    foreach ( $posts as $post_id => $notes ) {
        $body .= acorn_notes_render_post( (int) $post_id, $notes, $reply_counts );
    }

    return sprintf(
        '<section class="acorn-notes-type acorn-notes-type--%1$s">'
            . '<h2 class="acorn-notes-type-title">%2$s</h2>'
            . '%3$s'
        . '</section>',
        esc_attr( $post_type ),
        esc_html( $label ),
        $body
    );
}


// ============================================
// EMPTY STATE
// ============================================

//  How many note threads of a status this user can actually see. Counted through
//  acorn_notes_group() rather than a COUNT query, so the empty state cannot
//  advertise notes the list then refuses to show.
function acorn_notes_visible_count( string $status, int $limit ): int {
    $count = 0;

    foreach ( acorn_notes_group( acorn_notes_query( $status, $limit ) ) as $posts ) {
        foreach ( $posts as $notes ) {
            $count += count( $notes );
        }
    }

    return $count;
}

//  The panel that stands in for the list, as labelled lines rather than a bare
//  <p>. "No notes" is three situations: is-clear (done, here's the tally),
//  is-pending (none of this status, but notes exist), is-unused (never used).
function acorn_notes_render_empty( string $status, int $limit ): string {
    // The one status that is NOT the one asked for, so the panel can say
    // whether notes exist at all. 'all' came back empty, which already
    // answers it — nothing to count.
    $other = 'hold' === $status ? 'approve' : ( 'approve' === $status ? 'hold' : '' );
    $count = $other ? acorn_notes_visible_count( $other, $limit ) : 0;

    if ( ! $count ) {
        $variant = 'is-unused';
        $title   = __( 'No notes yet', 'acorn-creative' );
        $text    = __( 'This is where the notes left in the block editor collect — grouped by the page they sit on, in the order they appear down it.', 'acorn-creative' );
        $tally   = '';
    } elseif ( 'hold' === $status ) {
        $variant = 'is-clear';
        $title   = __( 'All clear', 'acorn-creative' );
        $text    = __( 'Every note left on this build has been resolved. New ones land here as they are written.', 'acorn-creative' );
        /* translators: %s: number of resolved notes. */
        $tally   = sprintf( _n( '%s note resolved', '%s notes resolved', $count, 'acorn-creative' ), number_format_i18n( $count ) );
    } else {
        $variant = 'is-pending';
        $title   = __( 'Nothing resolved yet', 'acorn-creative' );
        $text    = __( 'Notes move into this list once they are marked resolved in the editor.', 'acorn-creative' );
        /* translators: %s: number of open notes. */
        $tally   = sprintf( _n( '%s note still open', '%s notes still open', $count, 'acorn-creative' ), number_format_i18n( $count ) );
    }

    // Only when there is nothing to show the mechanics of. Once notes exist
    // the author has plainly found the feature, and the line is clutter.
    $hint = 'is-unused' === $variant
        ? __( 'To leave one, open a page in the editor, select the block — or just the words — it is about, and pick Notes from the toolbar.', 'acorn-creative' )
        : '';

    // Drawn by the child off the variant class; there is no glyph in here to
    // translate or to load.
    $mark = '<span class="acorn-notes-empty-mark" aria-hidden="true"></span>';

    $lines = sprintf( '<p class="acorn-notes-empty-title">%s</p>', esc_html( $title ) );

    if ( $tally ) {
        $lines .= sprintf( '<p class="acorn-notes-empty-tally is-style-small">%s</p>', esc_html( $tally ) );
    }

    $lines .= sprintf( '<p class="acorn-notes-empty-text">%s</p>', esc_html( $text ) );

    if ( $hint ) {
        $lines .= sprintf( '<p class="acorn-notes-empty-hint is-style-small">%s</p>', esc_html( $hint ) );
    }

    return sprintf(
        '<div class="acorn-notes-empty %1$s">%2$s<div class="acorn-notes-empty-body">%3$s</div></div>',
        esc_attr( $variant ),
        $mark,
        $lines
    );
}


// ============================================
// ASSETS
// ============================================

//  The resolve/reopen script, on any singular post whose content carries the
//  shortcode. A content sniff on wp_enqueue_scripts, not an enqueue inside the
//  shortcode, which runs during the_content — too late. Gated on edit_posts.
function acorn_notes_enqueue(): void {
    if ( ! is_singular() || ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
        return;
    }

    $content = (string) get_post_field( 'post_content', get_the_ID() );

    if ( ! has_shortcode( $content, 'acorn_notes' ) ) {
        return;
    }

    $path = get_template_directory() . '/acorn-stash/js/notes.js';

    if ( ! file_exists( $path ) ) {
        return;
    }

    wp_enqueue_script(
        'acorn-notes',
        get_template_directory_uri() . '/acorn-stash/js/notes.js',
        [],
        filemtime( $path ),
        true
    );

    // Printed before the file so the config is there when it runs. The nonce
    // is the only thing here that grants anything — the capability checks
    // behind it are core's, on every request.
    wp_add_inline_script(
        'acorn-notes',
        'window.acornNotes = ' . wp_json_encode(
            [
                'root'  => esc_url_raw( rest_url() ),
                'nonce' => wp_create_nonce( 'wp_rest' ),
                'i18n'  => [
                    'error'         => __( 'That did not save. Reload the page and try again.', 'acorn-creative' ),
                    'confirmDelete' => __( "Are you sure you want to delete this note? This will also delete all of this note's replies.", 'acorn-creative' ),
                ],
            ]
        ) . ';',
        'before'
    );
}
add_action( 'wp_enqueue_scripts', 'acorn_notes_enqueue' );


// ============================================
// SHORTCODE
// ============================================

function acorn_notes_shortcode( $atts ): string {
    $atts = shortcode_atts(
        [
            'status' => 'open',
            'limit'  => 200,
        ],
        $atts,
        'acorn_notes'
    );

    // Notes are private editorial content — never render for anyone who
    // could not open the editor in the first place.
    if ( ! is_user_logged_in() || ! current_user_can( 'edit_posts' ) ) {
        return '';
    }

    $statuses = [
        'open'     => 'hold',
        'resolved' => 'approve',
        'all'      => 'all',
    ];

    $status = $statuses[ strtolower( trim( (string) $atts['status'] ) ) ] ?? 'hold';
    $limit  = max( 1, (int) $atts['limit'] );

    $notes   = acorn_notes_query( $status, $limit );
    $grouped = acorn_notes_group( $notes );

    if ( ! $grouped ) {
        return acorn_notes_render_empty( $status, $limit );
    }

    $ids = [];

    foreach ( $grouped as $posts ) {
        foreach ( $posts as $post_notes ) {
            foreach ( $post_notes as $note ) {
                $ids[] = (int) $note->comment_ID;
            }
        }
    }

    $reply_counts = acorn_notes_reply_counts( $ids );

    $body = '';

    foreach ( $grouped as $post_type => $posts ) {
        $body .= acorn_notes_render_type( (string) $post_type, $posts, $reply_counts );
    }

    return '<div class="acorn-notes">' . $body . '</div>';
}
add_shortcode( 'acorn_notes', 'acorn_notes_shortcode' );
