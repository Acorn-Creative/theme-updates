<?php
// =============================================================
//  COLOR SWATCHES
// =============================================================
//  [acorn_color_swatches scheme="bg-1"] — one reference swatch per
//  background-scheme token, for the Stylesheet page. Colors come from the
//  child's generated acorn-stash/data/background-schemes.json.
//
//  Styled by the child's scss/_color-swatches.scss.
//
//  Why a shortcode and not hand-authored blocks:
//  CLAUDE.md § Pattern registration.
// =============================================================


// ============================================
// DATA
// ============================================

//  Scheme colors as literal hex, keyed by the background-color slug
//  WordPress emits ('default-bg', 'bg-1', …). Returns [] when the theme
//  has not been compiled yet.
function acorn_color_scheme_data(): array {
    static $schemes = null;

    if ( null === $schemes ) {
        $schemes = [];
        $path    = get_stylesheet_directory() . '/acorn-stash/data/background-schemes.json';

        if ( is_readable( $path ) ) {
            $decoded = json_decode( (string) file_get_contents( $path ), true );
            if ( is_array( $decoded ) ) {
                $schemes = $decoded;
            }
        }
    }

    return $schemes;
}

//  Accepts the WordPress slug ('bg-1'), the bare scheme key from
//  variables.js ('1', 'none'), or nothing at all for the page default.
function acorn_color_scheme_slug( string $scheme ): string {
    $scheme = trim( strtolower( $scheme ) );

    if ( '' === $scheme || 'none' === $scheme || 'default' === $scheme ) {
        return 'default-bg';
    }

    return preg_match( '/^\d+$/', $scheme ) ? "bg-{$scheme}" : $scheme;
}


// ============================================
// SHORTCODE
// ============================================

function acorn_color_swatches_shortcode( $atts ): string {
    $atts = shortcode_atts( [ 'scheme' => '' ], $atts, 'acorn_color_swatches' );
    $slug = acorn_color_scheme_slug( (string) $atts['scheme'] );

    $schemes = acorn_color_scheme_data();
    $tokens  = $schemes[ $slug ] ?? null;

    if ( ! $tokens ) {
        // Silent for visitors — a missing build artifact is not their problem.
        // Anyone who can edit the theme gets told what to run.
        if ( ! current_user_can( 'edit_theme_options' ) ) {
            return '';
        }

        $known = $schemes ? implode( ', ', array_keys( $schemes ) ) : '';

        return '<p class="color-swatch-notice">' . esc_html(
            $schemes
                ? sprintf(
                    /* translators: 1: requested scheme slug, 2: comma-separated list of available slugs */
                    __( 'Unknown color scheme "%1$s". Available: %2$s.', 'acorn-creative' ),
                    $slug,
                    $known
                )
                : __( 'Color scheme data not found — run "npm run build-theme" in the child theme.', 'acorn-creative' )
        ) . '</p>';
    }

    $items = '';

    foreach ( $tokens as $token => $hex ) {
        $items .= sprintf(
            '<div class="color-swatch-item wp-block-group is-vertical is-layout-flex">'
                . '<p class="is-style-small color-swatch-name"><code>--%1$s</code></p>'
                . '<p class="is-style-small color-swatch-hex">%2$s</p>'
                . '<div class="color-swatch color-swatch--%1$s" aria-hidden="true"></div>'
            . '</div>',
            esc_attr( $token ),
            esc_html( $hex )
        );
    }

    return '<div class="color-swatch-grid">' . $items . '</div>';
}
add_shortcode( 'acorn_color_swatches', 'acorn_color_swatches_shortcode' );
