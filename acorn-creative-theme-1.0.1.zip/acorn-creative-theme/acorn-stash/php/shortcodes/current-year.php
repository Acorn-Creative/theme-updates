<?php
// =============================================================
//  CURRENT YEAR
// =============================================================
//  [acorn_current_year] — outputs the current four-digit year, for
//  copyright lines in footer template parts that would otherwise
//  need a manual edit every January.
//
//  wp_date() (not date()) so the year rolls over on the site's
//  timezone, not the server's UTC clock.
//
//  Optional format attribute passes through to wp_date, so
//  [acorn_current_year format="y"] gives "26" and
//  [acorn_current_year format="F Y"] gives the month too.
// =============================================================

function acorn_current_year_shortcode( $atts ): string {
    $atts = shortcode_atts( [ 'format' => 'Y' ], $atts, 'acorn_current_year' );

    return esc_html( wp_date( (string) $atts['format'] ) );
}
add_shortcode( 'acorn_current_year', 'acorn_current_year_shortcode' );
