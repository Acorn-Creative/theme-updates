<?php
// ============================================
// NAVIGATION BLOCK — ICON SUPPORT
// ============================================
// Scans the child theme's acorn-stash/icons/core/navigation/ directory. The
// filename IS the role: submenu.svg (dropdown chevron), open.svg (overlay
// toggle), close.svg (overlay close).
//
// Four block + wrapper-class pairings, one render_block filter each, and both
// `close` rows are load-bearing — CLAUDE.md § Custom block icons.
//
// Frontend: render_block swaps the core <svg> in place.
// Editor:   CSS mask-image via JS canvas injection (navigation.js).

const ACORN_NAVIGATION_ICON_ROLES = [ 'submenu', 'open', 'close' ];


// ============================================
// ICON DATA
// ============================================
function acorn_navigation_icon_data(): array {
    static $cache = null;
    if ( $cache !== null ) return $cache;

    $dir = get_stylesheet_directory() . '/acorn-stash/icons/core/navigation/';
    if ( ! is_dir( $dir ) ) return $cache = [];

    $cache = [];
    foreach ( glob( $dir . '*.svg' ) as $file ) {
        $slug    = basename( $file, '.svg' );
        // dataUrl is used by navigation.js for the editor — avoids URL loading
        // issues (HTTPS cert, CORS) that can silently break mask-image in the canvas.
        $cache[] = [
            'slug'    => $slug,
            'url'     => get_stylesheet_directory_uri() . '/acorn-stash/icons/core/navigation/' . $slug . '.svg',
            'dataUrl' => 'data:image/svg+xml;base64,' . base64_encode( file_get_contents( $file ) ),
            'path'    => $file,
        ];
    }
    return $cache;
}


// ============================================
// EDITOR: Pass icon data to navigation.js
// ============================================
function acorn_maybe_enqueue_navigation_icons(): void {
    $for_js = acorn_icon_js_map( acorn_navigation_icon_data(), ACORN_NAVIGATION_ICON_ROLES );
    if ( empty( $for_js ) ) return;

    wp_add_inline_script(
        'acorn-theme-block-core-navigation-editor',
        'window.acornNavigationIcons = ' . wp_json_encode( $for_js ) . ';',
        'before'
    );
}
add_action( 'enqueue_block_editor_assets', 'acorn_maybe_enqueue_navigation_icons', 20 );


// ============================================
// HELPERS
// ============================================

// Prepares one role's SVG for injection: strips XML/doctype cruft, seeds
// class="icon-{slug} navigation-icon" (the sizing hook the child SCSS targets),
// and forces aria-hidden since every icon here is decorative.
function acorn_navigation_icon_svg( array $icon ): string {
    $svg = acorn_add_icon_class( acorn_clean_svg( file_get_contents( $icon['path'] ) ), $icon['slug'] );
    $svg = preg_replace_callback(
        '/<svg\b([^>]*?)class=(["\'])([^"\']*)\2/i',
        fn( $m ) => '<svg' . $m[1] . 'class=' . $m[2] . trim( $m[3] . ' navigation-icon' ) . $m[2],
        $svg,
        1
    );
    return preg_replace( '/<svg\b/i', '<svg aria-hidden="true"', $svg, 1 );
}

// Replaces the core <svg> sitting directly inside the element carrying
// $wrapper_class. Doubles as the hasIcon gate, and is safe to re-run over
// already-swapped markup. $limit: CLAUDE.md § Custom block icons.
function acorn_navigation_swap_svg( string $html, string $wrapper_class, string $svg, int $limit = 1 ): string {
    return preg_replace_callback(
        '/(<(?:span|button)\b[^>]*' . preg_quote( $wrapper_class, '/' ) . '[^>]*>)\s*<svg\b.*?<\/svg>/is',
        fn( $m ) => $m[1] . $svg,
        $html,
        $limit
    );
}


// ============================================
// FRONTEND: Submenu chevron
// ============================================
// Two blocks draw this chevron: core/navigation-submenu, and core/page-list,
// which renders the whole menu — chevrons included — and never delegates. Both
// emit the same wrapper classes. CLAUDE.md § Custom block icons.
function acorn_render_navigation_submenu_icon( string $block_content, array $block ): string {
    $chevron_blocks = array( 'core/navigation-submenu', 'core/page-list' );
    if ( ! in_array( $block['blockName'] ?? '', $chevron_blocks, true ) ) return $block_content;
    if ( ! str_contains( $block_content, 'wp-block-navigation__submenu-icon' ) ) return $block_content;

    $icon = acorn_icon_by_role( acorn_navigation_icon_data(), 'submenu', false );
    if ( ! $icon ) return $block_content;

    // -1, not the default 1: one page-list block carries every chevron in the
    // menu, so stopping at the first leaves the rest as core's.
    return acorn_navigation_swap_svg(
        $block_content,
        'wp-block-navigation__submenu-icon',
        acorn_navigation_icon_svg( $icon ),
        -1
    );
}
add_filter( 'render_block', 'acorn_render_navigation_submenu_icon', 10, 2 );


// ============================================
// FRONTEND: Overlay open + close buttons (core/navigation)
// ============================================
function acorn_render_navigation_overlay_icons( string $block_content, array $block ): string {
    if ( ( $block['blockName'] ?? '' ) !== 'core/navigation' ) return $block_content;
    if ( ! str_contains( $block_content, 'wp-block-navigation__responsive-container-' ) ) return $block_content;

    $icons = acorn_navigation_icon_data();
    if ( empty( $icons ) ) return $block_content;

    // Each role is independent — a child theme may supply open.svg without close.svg.
    foreach ( [ 'open', 'close' ] as $role ) {
        $icon = acorn_icon_by_role( $icons, $role, false );
        if ( ! $icon ) continue;

        $block_content = acorn_navigation_swap_svg(
            $block_content,
            'wp-block-navigation__responsive-container-' . $role,
            acorn_navigation_icon_svg( $icon )
        );
    }

    return $block_content;
}
add_filter( 'render_block', 'acorn_render_navigation_overlay_icons', 10, 2 );


// ============================================
// FRONTEND: Overlay close, WP 7.0 block (core/navigation-overlay-close)
// ============================================
// A second close button, at a different class on a different block: core drops
// its own close button as soon as a nav resolves a custom overlay part, so the
// filter above no-ops there and both have to stay. CLAUDE.md § Custom block icons.
function acorn_render_navigation_overlay_close_icon( string $block_content, array $block ): string {
    if ( ( $block['blockName'] ?? '' ) !== 'core/navigation-overlay-close' ) return $block_content;

    $icon = acorn_icon_by_role( acorn_navigation_icon_data(), 'close', false );
    if ( ! $icon ) return $block_content;

    // The hasIcon gate again: with the block set to show text there is no
    // <svg> to match and this no-ops.
    return acorn_navigation_swap_svg(
        $block_content,
        'wp-block-navigation-overlay-close',
        acorn_navigation_icon_svg( $icon )
    );
}
add_filter( 'render_block', 'acorn_render_navigation_overlay_close_icon', 10, 2 );
