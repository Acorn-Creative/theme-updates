<?php
// =============================================================
//  Gallery — Masonry Style Variation
//  Description: Registers a "Masonry" block style on core/gallery,
//  giving editors a one-click option in the block's Styles panel
//  that switches the gallery from the even flex grid to a
//  staggered, column-packed masonry layout.
//
//  Registration is pure PHP — no editor JS. Core adds the picker,
//  writes `is-style-masonry` into the saved className, and serializes
//  it to the frontend. The appearance lives in the child theme
//  (acorn-stash/scss/blocks/core/gallery.scss, auto-enqueued for
//  core/gallery on both editor and frontend).
//
//  @package Acorn Creative
//  @since 1.0.0
// =============================================================

add_action( 'init', function() {
    register_block_style( 'core/gallery', array(
        'name'  => 'masonry',
        'label' => __( 'Masonry', 'acorn-creative-theme' ),
    ) );
} );


// ============================================
// SINGLE (LINKED) BLOCK-SPACING CONTROL
// ============================================
// Collapsing blockGap to `true` replaces the editor's split H/V control with one
// linked control, whose single string drives the masonry layout's column-gap AND
// row-gap. Applies to every gallery — CLAUDE.md § `core/gallery`.
add_filter( 'block_type_metadata_settings', function( $settings, $metadata ) {
    if ( ( $metadata['name'] ?? '' ) !== 'core/gallery' ) {
        return $settings;
    }
    if ( isset( $settings['supports']['spacing']['blockGap'] ) ) {
        $settings['supports']['spacing']['blockGap'] = true;
    }
    return $settings;
}, 10, 2 );
