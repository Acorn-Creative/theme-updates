<?php
// ============================================
/// QUOTE / PULLQUOTE BLOCK — ICON SUPPORT
// ============================================
// Scans the child theme's acorn-stash/icons/core/block-quote/ directory.
// Single-slot: role 'mark' is injected as a decorative quotation
// mark at the top of core/quote and core/pullquote.
// Frontend: render_block injects the SVG as the first child of <blockquote>.
// Editor:   CSS mask-image via JS canvas injection (block-quote.js).

function acorn_block_quote_icon_data(): array {
    static $cache = null;
    if ( $cache !== null ) return $cache;

    $dir = get_stylesheet_directory() . '/acorn-stash/icons/core/block-quote/';
    if ( ! is_dir( $dir ) ) return $cache = [];

    $cache = [];
    foreach ( glob( $dir . '*.svg' ) as $file ) {
        $slug    = basename( $file, '.svg' );
        // dataUrl is used by block-quote.js for the editor — avoids URL loading
        // issues (HTTPS cert, CORS) that can silently break mask-image in the canvas.
        $cache[] = [
            'slug'    => $slug,
            'url'     => get_stylesheet_directory_uri() . '/acorn-stash/icons/core/block-quote/' . $slug . '.svg',
            'dataUrl' => 'data:image/svg+xml;base64,' . base64_encode( file_get_contents( $file ) ),
            'path'    => $file,
        ];
    }
    return $cache;
}


// ============================================
// EDITOR: Pass icon data to block-quote.js
// ============================================
function acorn_maybe_enqueue_block_quote_icons(): void {
    $icons = acorn_block_quote_icon_data();
    if ( empty( $icons ) ) return;

    $for_js = acorn_icon_js_map( $icons, [ 'mark' ] );
    if ( empty( $for_js ) ) return;

    wp_add_inline_script(
        'acorn-theme-block-core-block-quote-editor',
        'window.acornBlockQuoteIcons = ' . wp_json_encode( $for_js ) . ';',
        'before'
    );
}
add_action( 'enqueue_block_editor_assets', 'acorn_maybe_enqueue_block_quote_icons', 20 );


// ============================================
// FRONTEND: Inject SVG into the <blockquote>
// ============================================
function acorn_render_block_quote_icon( string $block_content, array $block ): string {
    $name = $block['blockName'] ?? '';
    if ( $name !== 'core/quote' && $name !== 'core/pullquote' ) return $block_content;
    if ( ! str_contains( $block_content, '<blockquote' ) ) return $block_content;

    $icons = acorn_block_quote_icon_data();
    if ( empty( $icons ) ) return $block_content;

    $icon = acorn_icon_by_role( $icons, 'mark' );
    if ( ! $icon ) return $block_content;
    $svg  = acorn_clean_svg( file_get_contents( $icon['path'] ) );
    // acorn_add_icon_class adds the per-icon class (icon-{slug}); a second pass
    // adds the generic .block-quote-icon hook the SCSS sizes/colors.
    $svg  = acorn_add_icon_class( $svg, $icon['slug'] );
    $svg  = preg_replace_callback(
        '/class=["\']([^"\']*)["\']/i',
        fn( $m ) => 'class="' . trim( $m[1] . ' block-quote-icon' ) . '"',
        $svg,
        1
    );
    // SVG is decorative — the quote text conveys the meaning.
    $svg  = preg_replace( '/<svg\b/i', '<svg aria-hidden="true"', $svg, 1 );

    // Insert right after the opening <blockquote ...> tag — works for
    // core/quote (blockquote is the root) and core/pullquote (blockquote
    // sits inside the <figure>).
    return preg_replace_callback(
        '/(<blockquote\b[^>]*>)/i',
        fn( $m ) => $m[1] . $svg,
        $block_content,
        1
    );
}
add_filter( 'render_block', 'acorn_render_block_quote_icon', 10, 2 );
