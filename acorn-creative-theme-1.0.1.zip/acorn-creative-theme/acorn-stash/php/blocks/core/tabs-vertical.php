<?php
// =============================================================
//  Tabs — Vertical Style Variation
//  Description: Registers a "Vertical" block style on core/tabs,
//  giving editors a one-click option in the block's Styles panel
//  that moves the tab list from a horizontal rail above the
//  panels to a vertical rail beside them.
//
//  Registration is pure PHP — no editor JS. Core adds the picker,
//  writes `is-style-vertical` into the saved className, and
//  serializes it to the frontend. The appearance lives in the
//  child theme (acorn-stash/scss/blocks/core/tabs.scss, auto-
//  enqueued for core/tabs on both editor and frontend).
//
//  @package Acorn Creative
//  @since 1.0.0
// =============================================================

add_action( 'init', function() {
    register_block_style( 'core/tabs', array(
        'name'  => 'vertical',
        'label' => __( 'Vertical', 'acorn-creative-theme' ),
    ) );
} );
