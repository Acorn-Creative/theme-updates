<?php
// ============================================
/// DETAILS BLOCK — ICON SUPPORT
// ============================================
// Scans the child theme's acorn-stash/icons/core/details/ directory.
// Single-slot: role 'marker' replaces the native <summary> disclosure
// marker (the browser default triangle — core/details renders no marker element).
// Frontend: render_block injects the SVG as the first child of <summary>.
// Editor:   CSS mask-image via JS canvas injection (details.js).

function acorn_details_icon_data(): array {
    static $cache = null;
    if ( $cache !== null ) return $cache;

    $dir = get_stylesheet_directory() . '/acorn-stash/icons/core/details/';
    if ( ! is_dir( $dir ) ) return $cache = [];

    $cache = [];
    foreach ( glob( $dir . '*.svg' ) as $file ) {
        $slug    = basename( $file, '.svg' );
        // dataUrl is used by details.js for the editor — avoids URL loading
        // issues (HTTPS cert, CORS) that can silently break mask-image in the canvas.
        $cache[] = [
            'slug'    => $slug,
            'url'     => get_stylesheet_directory_uri() . '/acorn-stash/icons/core/details/' . $slug . '.svg',
            'dataUrl' => 'data:image/svg+xml;base64,' . base64_encode( file_get_contents( $file ) ),
            'path'    => $file,
        ];
    }
    return $cache;
}


// ============================================
// EDITOR: Pass icon data to details.js
// ============================================
function acorn_maybe_enqueue_details_icons(): void {
    $icons = acorn_details_icon_data();
    if ( empty( $icons ) ) return;

    $for_js = acorn_icon_js_map( $icons, [ 'marker' ] );
    if ( empty( $for_js ) ) return;

    wp_add_inline_script(
        'acorn-theme-block-core-details-editor',
        'window.acornDetailsIcons = ' . wp_json_encode( $for_js ) . ';',
        'before'
    );
}
add_action( 'enqueue_block_editor_assets', 'acorn_maybe_enqueue_details_icons', 20 );


// ============================================
// FRONTEND: Inject SVG into the <summary> marker
// ============================================
function acorn_render_details_icon( string $block_content, array $block ): string {
    if ( ( $block['blockName'] ?? '' ) !== 'core/details' ) return $block_content;
    if ( ! str_contains( $block_content, '<summary' ) ) return $block_content;

    $icons = acorn_details_icon_data();
    if ( empty( $icons ) ) return $block_content;

    $icon = acorn_icon_by_role( $icons, 'marker' );
    if ( ! $icon ) return $block_content;
    $svg  = acorn_clean_svg( file_get_contents( $icon['path'] ) );
    // acorn_add_icon_class adds the per-icon class (icon-{slug}); a second pass
    // with the 'details' slug yields the generic icon-details hook. SCSS sizes
    // both via .details-icon, which we add below alongside them.
    $svg  = acorn_add_icon_class( $svg, $icon['slug'] );
    // Add the .details-icon hook the SCSS targets, merging into the existing class.
    $svg  = preg_replace_callback(
        '/class=["\']([^"\']*)["\']/i',
        fn( $m ) => 'class="' . trim( $m[1] . ' details-icon' ) . '"',
        $svg,
        1
    );
    // SVG is decorative — the <summary> text conveys the control's purpose
    $svg  = preg_replace( '/<svg\b/i', '<svg aria-hidden="true"', $svg, 1 );

    return preg_replace_callback(
        '/(<summary\b[^>]*>)/i',
        fn( $m ) => $m[1] . $svg,
        $block_content,
        1
    );
}
add_filter( 'render_block', 'acorn_render_details_icon', 10, 2 );
