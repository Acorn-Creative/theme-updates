<?php
// =============================================================
//  Page List — Unwrap Inside Navigation
// =============================================================
//  Drops the <ul> core/page-list renders around its own items when the list
//  sits directly inside core/navigation, which has already opened
//  <ul class="wp-block-navigation__container">. Left alone the two stack into
//  `ul > ul`, which is invalid list markup.
//
//  Why core does not handle it, why a nav with no menu hits it too, and why
//  this is filtered rather than fixed in the markup:
//  CLAUDE.md § `core/page-list` inside a navigation.
//
//  @package Acorn Creative
//  @since 1.0.0
// =============================================================

// `showSubmenuIcon` is the context key core itself tests to decide a page-list
// has a navigation parent — core/navigation is its only provider.
function acorn_unwrap_page_list_in_navigation( $block_content, $block, $instance ) {
    if ( ! array_key_exists( 'showSubmenuIcon', $instance->context ) ) {
        return $block_content;
    }

    $trimmed = trim( $block_content );

    // Bail unless the whole render really is one <ul> … </ul>. A page-list
    // inside a submenu already comes back as bare <li>s and must pass through
    // untouched, as must an empty render on a site with no pages.
    if ( 0 !== strpos( $trimmed, '<ul' ) || '</ul>' !== substr( $trimmed, -5 ) ) {
        return $block_content;
    }

    $open_tag_end = strpos( $trimmed, '>' );
    if ( false === $open_tag_end ) {
        return $block_content;
    }

    // The wrapper's own attributes go with it. That is the point — the
    // surviving <ul> is the navigation's, and core's nested path discards
    // them in exactly the same way.
    return substr( $trimmed, $open_tag_end + 1, -5 );
}
add_filter( 'render_block_core/page-list', 'acorn_unwrap_page_list_in_navigation', 10, 3 );
