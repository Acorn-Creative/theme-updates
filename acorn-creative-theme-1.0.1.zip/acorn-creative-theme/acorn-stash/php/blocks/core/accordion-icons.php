<?php
// ============================================
/// ACCORDION BLOCK — ICON SUPPORT
// ============================================
// Scans the child theme's acorn-stash/icons/core/accordion/ directory.
// Single-slot: role 'toggle' replaces the default '+' toggle icon. A lone SVG
// resolves whatever it's named; add a second and one must be toggle.svg.
// Frontend: render_block injection into core/accordion-item.
// Editor:   CSS mask-image via JS canvas injection (accordion.js).

function acorn_accordion_icon_data(): array {
    static $cache = null;
    if ( $cache !== null ) return $cache;

    $dir = get_stylesheet_directory() . '/acorn-stash/icons/core/accordion/';
    if ( ! is_dir( $dir ) ) return $cache = [];

    $cache = [];
    foreach ( glob( $dir . '*.svg' ) as $file ) {
        $slug    = basename( $file, '.svg' );
        // dataUrl is used by accordion.js for the editor — avoids URL loading
        // issues (HTTPS cert, CORS) that can silently break mask-image in the canvas.
        $cache[] = [
            'slug'    => $slug,
            'url'     => get_stylesheet_directory_uri() . '/acorn-stash/icons/core/accordion/' . $slug . '.svg',
            'dataUrl' => 'data:image/svg+xml;base64,' . base64_encode( file_get_contents( $file ) ),
            'path'    => $file,
        ];
    }
    return $cache;
}


// ============================================
// EDITOR: Pass icon data to accordion.js
// ============================================
function acorn_maybe_enqueue_accordion_icons(): void {
    $icons = acorn_accordion_icon_data();
    if ( empty( $icons ) ) return;

    $for_js = acorn_icon_js_map( $icons, [ 'toggle' ] );
    if ( empty( $for_js ) ) return;

    wp_add_inline_script(
        'acorn-theme-block-core-accordion-editor',
        'window.acornAccordionIcons = ' . wp_json_encode( $for_js ) . ';',
        'before'
    );
}
add_action( 'enqueue_block_editor_assets', 'acorn_maybe_enqueue_accordion_icons', 20 );


// ============================================
// FRONTEND: Inject SVG into toggle icon span
// ============================================
function acorn_render_accordion_icon( string $block_content, array $block ): string {
    if ( ( $block['blockName'] ?? '' ) !== 'core/accordion-item' ) return $block_content;
    if ( ! str_contains( $block_content, 'wp-block-accordion-heading__toggle-icon' ) ) return $block_content;

    $icons = acorn_accordion_icon_data();
    if ( empty( $icons ) ) return $block_content;

    $icon = acorn_icon_by_role( $icons, 'toggle' );
    if ( ! $icon ) return $block_content;
    $svg  = acorn_clean_svg( file_get_contents( $icon['path'] ) );
    $svg  = acorn_add_icon_class( $svg, $icon['slug'] );
    // Ensure aria-hidden since the span already carries it and the SVG is decorative
    $svg  = preg_replace( '/<svg\b/i', '<svg aria-hidden="true"', $svg, 1 );

    return preg_replace_callback(
        '/(<span\b[^>]+wp-block-accordion-heading__toggle-icon[^>]*>)\+(<\/span>)/i',
        fn( $m ) => $m[1] . $svg . $m[2],
        $block_content
    );
}
add_filter( 'render_block', 'acorn_render_accordion_icon', 10, 2 );
