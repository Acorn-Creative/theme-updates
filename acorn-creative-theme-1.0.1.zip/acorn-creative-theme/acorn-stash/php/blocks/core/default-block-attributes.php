<?php
// =============================================================
//  Default Block Attributes
//  Description: Sets default attribute values for core blocks,
//  equivalent to "Set globally" in the editor but defined in code.
//
//  @package Acorn Creative
//  @since 1.0.0
// =============================================================

add_filter( 'block_type_metadata_settings', function( $settings, $metadata ) {

    switch ( $metadata['name'] ) {

        case 'core/breadcrumbs':
            $settings['attributes']['separator']['default']    = '|';
            $settings['attributes']['showHomeItem']['default'] = false;
            break;

    }

    return $settings;

}, 10, 2 );
