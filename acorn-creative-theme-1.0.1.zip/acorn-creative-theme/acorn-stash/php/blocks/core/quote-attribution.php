<?php
// =============================================================
//  Quote / Pullquote — Citation Attribution
//  Description: The blocks' built-in citation is repurposed as the
//  AUTHOR (relabeled in the editor); this file registers the extra
//  `role` string attribute on core/quote + core/pullquote and, on the
//  frontend, appends <span class="quote-role"> inside the block's
//  <cite> after the author text (creating a <cite> if the author is
//  empty). Editor UI lives in acorn-stash/js/blocks/core/quote.js;
//  styling lives in the child (blocks/core/quote.scss + pullquote.scss).
//
//  @package Acorn Creative
//  @since 1.0.0
// =============================================================

const ACORN_ATTRIBUTION_BLOCKS = array( 'core/quote', 'core/pullquote' );

// --- Register the attribute server-side so it persists and is
//     available to render_block below. -----------------------------------
add_filter( 'block_type_metadata_settings', function ( $settings, $metadata ) {
    if ( in_array( $metadata['name'], ACORN_ATTRIBUTION_BLOCKS, true ) ) {
        $settings['attributes']['role'] = array( 'type' => 'string', 'default' => '' );
    }
    return $settings;
}, 10, 2 );

// --- Wrap the author + render the role into the <cite> on the frontend. ---
add_filter( 'render_block', function ( $content, $block ) {
    if ( empty( $block['blockName'] ) ||
         ! in_array( $block['blockName'], ACORN_ATTRIBUTION_BLOCKS, true ) ) {
        return $content;
    }

    // Wraps core's <cite> text so the child can key the "author | role" pipe on
    // the .quote-author + .quote-role adjacency — a bare text node cannot be
    // matched in CSS. Runs BEFORE role injection, so the role span lands second.
    if ( false !== strpos( $content, '</cite>' ) ) {
        $content = preg_replace(
            '/(<cite\b[^>]*>)(?!<span class="quote-author")(.+?)(<\/cite>)/s',
            '$1<span class="quote-author">$2</span>$3',
            $content,
            1
        );
    }

    $role = isset( $block['attrs']['role'] ) ? trim( $block['attrs']['role'] ) : '';

    if ( '' === $role ) {
        return $content;
    }

    // The attribute is edited via RichText, so it's already entity-encoded
    // text: wp_kses (not esc_html, which would double-encode entities)
    // strips any markup while keeping the encoding intact.
    $span = '<span class="quote-role">' . wp_kses( $role, array() ) . '</span>';

    // preg_replace_callback (not a replacement string) so role text
    // containing $ or \ can't corrupt the output via backreferences.
    if ( false !== strpos( $content, '</cite>' ) ) {
        // Append inside the existing <cite>, after the wrapped author span.
        return preg_replace_callback(
            '/<\/cite>/',
            function ( $m ) use ( $span ) { return $span . $m[0]; },
            $content,
            1
        );
    }

    // No citation present (role without an author) — add a <cite> just
    // before the closing blockquote.
    return preg_replace_callback(
        '/<\/blockquote>/',
        function ( $m ) use ( $span ) { return '<cite>' . $span . '</cite>' . $m[0]; },
        $content,
        1
    );
    // Priority 6: runs BEFORE the content wrapper (prio 8) so the <cite> —
    // including one this filter creates for a role-without-author — is wrapped
    // inside .quote-content, matching the editor.
}, 6, 2 );

// --- Wrap the quote body (content + <cite>) in <div class="quote-content"> ----
//  Lets the child flex the decorative quote icon alongside the text; the class is
//  a cross-file contract string. Priority 8: after role injection (6), before the
//  icon (10), so the <cite> is inside and the icon is a sibling.
add_filter( 'render_block', function ( $content, $block ) {
    if ( empty( $block['blockName'] ) ||
         ! in_array( $block['blockName'], ACORN_ATTRIBUTION_BLOCKS, true ) ) {
        return $content;
    }
    if ( false === strpos( $content, '<blockquote' ) ||
         false === strpos( $content, '</blockquote>' ) ) {
        return $content;
    }

    // Greedy `.*` binds to the LAST </blockquote>, so a nested quote's own close
    // cannot end the wrapper early. $2 reinserts the body verbatim.
    return preg_replace(
        '/(<blockquote\b[^>]*>)(.*)(<\/blockquote>)/s',
        '$1<div class="quote-content">$2</div>$3',
        $content,
        1
    );
}, 8, 2 );
