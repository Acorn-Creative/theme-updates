<?php
// =============================================================
//  Acorn Accordion Repeater
//  Description: Registers a JetEngine Dynamic Field callback that
//  renders a repeater field as a native core/accordion block.
//  do_blocks() runs the parsed markup through core, so the
//  Interactivity API script module and server-side directive
//  processing are handled by core automatically.
//
//  Usage: In the JetEngine Dynamic Field block, point the Meta
//  Field at any repeater whose rows expose `title` and `content`
//  subfields, then set Callback to "Acorn Accordion Repeater".
//
//  @package Acorn Creative
// =============================================================

add_filter( 'jet-engine/listings/allowed-callbacks', function( $callbacks ) {
    $callbacks['acorn_accordion_repeater'] = __( 'Acorn Accordion Repeater', 'acorn-creative' );
    return $callbacks;
} );

function acorn_accordion_repeater( $rows ) {

    // JetEngine sometimes hands repeater values back as JSON strings
    if ( is_string( $rows ) ) {
        $decoded = json_decode( $rows, true );
        $rows    = is_array( $decoded ) ? $decoded : null;
    }

    if ( empty( $rows ) || ! is_array( $rows ) ) {
        return '';
    }

    $blocks  = '<!-- wp:accordion {"autoclose":true} -->';
    $blocks .= '<div role="group" class="wp-block-accordion">';

    foreach ( $rows as $row ) {
        $title   = $row['title']   ?? '';
        $content = $row['content'] ?? '';

        $blocks .= '<!-- wp:accordion-item -->';
        $blocks .= '<div class="wp-block-accordion-item">';

        $blocks .= '<!-- wp:accordion-heading -->';
        $blocks .= '<h3 class="wp-block-accordion-heading">'
                    . '<button type="button" class="wp-block-accordion-heading__toggle">'
                        . '<span class="wp-block-accordion-heading__toggle-title">' . esc_html( $title ) . '</span>'
                        . '<span class="wp-block-accordion-heading__toggle-icon" aria-hidden="true">+</span>'
                    . '</button>'
                . '</h3>';
        $blocks .= '<!-- /wp:accordion-heading -->';

        $blocks .= '<!-- wp:accordion-panel -->';
        $blocks .= '<div role="region" class="wp-block-accordion-panel">'
                    . '<!-- wp:html -->'
                    . $content
                    . '<!-- /wp:html -->'
                . '</div>';
        $blocks .= '<!-- /wp:accordion-panel -->';

        $blocks .= '</div>';
        $blocks .= '<!-- /wp:accordion-item -->';
    }

    $blocks .= '</div>';
    $blocks .= '<!-- /wp:accordion -->';

    return do_blocks( $blocks );
}
