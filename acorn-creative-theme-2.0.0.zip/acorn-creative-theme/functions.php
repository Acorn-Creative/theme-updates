<?php
// =============================================================
//  Acorn Creative Theme Functions
//  Description: Core theme setup and asset enqueueing for
//  the Acorn Creative parent theme.
//
//  @link https://developer.wordpress.org/themes/basics/theme-functions/
//  @package Acorn Creative
//  @since 1.0.0
// =============================================================


// ============================================
/// THEME UPDATES
// ============================================
require_once get_template_directory() . '/acorn-stash/php/site/theme-updater.php';

// ============================================
/// LOGIN PAGE
// ============================================
require_once get_template_directory() . '/acorn-stash/php/site/login.php';

// ============================================
/// LINK ICONS
// ============================================
// Not a block feature — a global render_block filter that decorates any
// <a> inside .has-icon, so it lives under php/site/ with icons at
// acorn-stash/icons/site/link/.
require_once get_template_directory() . '/acorn-stash/php/site/link-icons.php';

// ============================================
/// BLOCK EXTENSIONS
// ============================================
// One file per block feature under php/blocks/{ns}/, mirroring the
// editor JS at js/blocks/{ns}/. button-icons.php stays first — it
// defines the shared SVG helpers the other icon features call.
require_once get_template_directory() . '/acorn-stash/php/blocks/core/button-icons.php';
require_once get_template_directory() . '/acorn-stash/php/blocks/core/accordion-icons.php';
require_once get_template_directory() . '/acorn-stash/php/blocks/core/details-icons.php';
require_once get_template_directory() . '/acorn-stash/php/blocks/core/navigation-icons.php';
require_once get_template_directory() . '/acorn-stash/php/blocks/core/block-quote-icons.php';
require_once get_template_directory() . '/acorn-stash/php/blocks/core/default-block-attributes.php';
require_once get_template_directory() . '/acorn-stash/php/blocks/core/quote-attribution.php';
require_once get_template_directory() . '/acorn-stash/php/blocks/core/gallery-masonry.php';
require_once get_template_directory() . '/acorn-stash/php/blocks/core/tabs-vertical.php';
require_once get_template_directory() . '/acorn-stash/php/blocks/core/page-list-nesting.php';

// ============================================
/// SITE FEATURES
// ============================================
require_once get_template_directory() . '/acorn-stash/php/site/animations.php';
// Sinks the "Acorn Documentation" page + its children to the bottom of the
// admin Pages list (ORDER BY flag, not a menu_order write). Slug list is
// filterable via 'acorn_admin_trailing_pages'.
require_once get_template_directory() . '/acorn-stash/php/site/admin-page-order.php';
// Gives the `search` template two states — a landing page when nothing has been
// searched for, a results page once it has. Three hooks, and a class string that
// is a contract with that template's DB post. CLAUDE.md § Search.
require_once get_template_directory() . '/acorn-stash/php/site/search-states.php';

// ============================================
/// SHORTCODES
// ============================================
// One file per shortcode under php/shortcodes/, named for the tag it registers.
// [acorn_color_swatches] reads the child's generated background-schemes.json, so
// it no-ops on an uncompiled child rather than fataling.
require_once get_template_directory() . '/acorn-stash/php/shortcodes/color-swatches.php';
require_once get_template_directory() . '/acorn-stash/php/shortcodes/current-year.php';
// [acorn_notes] lists the block editor's Notes (WP 6.9+ comment_type 'note'),
// grouped by post type then post. Renders nothing unless the viewer can edit.
require_once get_template_directory() . '/acorn-stash/php/shortcodes/notes.php';

// ============================================
/// THIRD-PARTY INTEGRATIONS
// ============================================
require_once get_template_directory() . '/acorn-stash/php/integrations/jet-engine/repeater-accordion.php';

// ============================================
/// BLOCK PATTERNS
// ============================================
require_once get_template_directory() . '/acorn-stash/php/site/patterns.php';




// ============================================
/// ENQUEUE BLOCK EDITOR SCRIPTS
// ============================================
// Auto-discovers JS files in acorn-stash/js/blocks/ and enqueues each one.
// The folder and filename only form the script handle — they don't need to
// match a block name: acorn-stash/js/blocks/core/button.js → acorn-theme-block-core-button-editor
function acorn_enqueue_block_editor_scripts() {
    $block_scripts = glob( get_template_directory() . '/acorn-stash/js/blocks/*/*.js' );

    if ( ! $block_scripts ) return;

    foreach ( $block_scripts as $file_path ) {
        preg_match( '/js\/blocks\/([^\/]+)\/([^\/]+)\.js$/', $file_path, $matches );
        if ( empty( $matches ) || count( $matches ) !== 3 ) continue;

        $namespace  = $matches[1];
        $block_name = $matches[2];
        $handle     = "acorn-theme-block-{$namespace}-{$block_name}-editor";

        wp_enqueue_script(
            $handle,
            get_template_directory_uri() . "/acorn-stash/js/blocks/{$namespace}/{$block_name}.js",
            array( 'wp-hooks', 'wp-block-editor', 'wp-components', 'wp-compose', 'wp-element' ),
            filemtime( $file_path )
        );
    }
}
add_action( 'enqueue_block_editor_assets', 'acorn_enqueue_block_editor_scripts' );


// ============================================
/// ENQUEUE EDITOR STYLES
// ============================================
// style-admin.css targets sidebar/inspector elements (outside the canvas iframe),
// so it must be enqueued via enqueue_block_editor_assets, not add_editor_style().
add_action( 'enqueue_block_editor_assets', function() {
    $version = filemtime( get_template_directory() . '/style-admin.css' );
    wp_enqueue_style(
        'acorn-admin-styles',
        get_template_directory_uri() . '/style-admin.css',
        array(),
        $version
    );
} );


// ============================================
/// ENQUEUE FRONTEND STYLES
// ============================================
function acorn_enqueue_styles() {
    $css_path = get_template_directory() . '/style.css';

    // Skip the request entirely while the stylesheet holds only the theme header.
    // The handle is still registered (src false) so the child theme's
    // dependency on it keeps resolving.
    $rules = trim( preg_replace( '!/\*.*?\*/!s', '', file_get_contents( $css_path ) ) );
    if ( '' === $rules ) {
        wp_register_style( 'acorn-creative-theme', false );
        return;
    }

    wp_enqueue_style(
        'acorn-creative-theme',
        get_template_directory_uri() . '/style.css',
        array(),
        filemtime( $css_path )
    );
}
add_action( 'wp_enqueue_scripts', 'acorn_enqueue_styles' );


// ============================================
/// PRELOAD CRITICAL FONTS
// ============================================
// Preloads only the faces named in the merged theme.json's
// settings.custom.preloadFonts — an array of file names
// ("Poppins-Regular.woff2") or the same `file:./` paths used in a fontFace
// src. Preloading a face that does not render above the fold costs bandwidth
// the LCP image needs, so the allowlist is deliberately short; with the key
// missing nothing is preloaded and every face still loads via font-display:
// swap. `acorn_preload_fonts` filters the final URL list either way.
// `crossorigin` is required for font preloads even on the same origin.
add_action( 'wp_head', function() {
    $allowlist = wp_get_global_settings( [ 'custom', 'preloadFonts' ] );
    $allowlist = is_array( $allowlist ) ? array_filter( $allowlist, 'is_string' ) : [];

    // File names, so an entry matches whether it is written as a bare name or
    // as a full `file:./` path.
    $allowed_files = array_values( array_unique(
        array_map( fn( $entry ) => strtolower( basename( $entry ) ), $allowlist )
    ) );

    $urls_by_file = [];

    $families = wp_get_global_settings( [ 'typography', 'fontFamilies' ] )['theme'] ?? [];
    foreach ( $families as $family ) {
        foreach ( $family['fontFace'] ?? [] as $face ) {
            foreach ( (array) ( $face['src'] ?? [] ) as $src ) {
                $file = strtolower( basename( (string) $src ) );
                if ( ! in_array( $file, $allowed_files, true ) ) continue;

                if ( str_starts_with( $src, 'file:./' ) ) {
                    // Resolves against the child theme first, then the parent —
                    // the same lookup WP uses for theme.json file: sources.
                    $src = get_theme_file_uri( substr( $src, 7 ) );
                }
                $urls_by_file[ $file ] ??= $src;
            }
        }
    }

    // Allowlist order, not declaration order — the list is written worst-case
    // first, and the browser requests the preloads in the order they appear.
    $font_urls = [];
    foreach ( $allowed_files as $file ) {
        if ( isset( $urls_by_file[ $file ] ) ) $font_urls[] = $urls_by_file[ $file ];
    }

    $font_urls = apply_filters( 'acorn_preload_fonts', $font_urls );

    $mime_types = [ 'woff2' => 'font/woff2', 'woff' => 'font/woff', 'ttf' => 'font/ttf', 'otf' => 'font/otf' ];

    foreach ( $font_urls as $font_url ) {
        // A mismatched type makes the browser discard the preload, so derive it
        $ext = strtolower( pathinfo( (string) wp_parse_url( $font_url, PHP_URL_PATH ), PATHINFO_EXTENSION ) );
        printf(
            '<link rel="preload" href="%s" as="font" type="%s" crossorigin>' . "\n",
            esc_url( $font_url ),
            esc_attr( $mime_types[ $ext ] ?? 'font/' . $ext )
        );
    }
}, 2 );


// ============================================
/// ADOBE FONTS (TYPEKIT)
// ============================================
// Enqueues a kit stylesheet and preconnect per Adobe Fonts project ID in the
// merged theme.json's settings.custom.adobeFonts. enqueue_block_assets covers
// the frontend and the editor canvas iframe both.
function acorn_adobe_fonts_ids() {
    $ids = wp_get_global_settings( [ 'custom', 'adobeFonts' ] );
    return is_array( $ids ) ? array_filter( $ids, 'is_string' ) : [];
}

add_action( 'enqueue_block_assets', function() {
    foreach ( acorn_adobe_fonts_ids() as $id ) {
        wp_enqueue_style( 'acorn-adobe-fonts-' . $id, "https://use.typekit.net/{$id}.css", [], null );
    }
} );

add_filter( 'wp_resource_hints', function( $urls, $relation ) {
    if ( 'preconnect' === $relation && acorn_adobe_fonts_ids() ) {
        $urls[] = [ 'href' => 'https://use.typekit.net', 'crossorigin' ];
    }
    return $urls;
}, 10, 2 );


// ============================================
/// ENQUEUE BG SWITCHER SCRIPT
// ============================================
// Loads only on singular pages whose content contains a .bg-switcher group.
// The script file lives in the child theme so it stays editable per-project.
add_action( 'wp_enqueue_scripts', function() {
    if ( ! is_singular() ) return;
    if ( ! str_contains( get_post_field( 'post_content', get_the_ID() ), 'bg-switcher' ) ) return;

    $path = get_stylesheet_directory() . '/acorn-stash/js/bg-switcher.js';
    if ( ! file_exists( $path ) ) return;

    wp_enqueue_script(
        'acorn-bg-switcher',
        get_stylesheet_directory_uri() . '/acorn-stash/js/bg-switcher.js',
        array(),
        filemtime( $path ),
        true
    );
} );


// ============================================
/// DISABLE FONT LIBRARY
// ============================================
add_filter( 'wp_font_library_allow_font_face_url', '__return_false' );


// ============================================
/// PREVENT PARENT THEME BLOCK STYLES FROM LOADING
// ============================================
add_action( 'enqueue_block_assets', function() {
    wp_dequeue_style( 'wp-block-library-theme' );
}, 100 );


// ============================================
/// REMOVE CORE WORDPRESS PATTERNS
// ============================================
add_action( 'after_setup_theme', function() {
    remove_theme_support( 'core-block-patterns' );
} );


// ============================================
/// ADD CUSTOM CLASS TO <body>
// ============================================
add_filter('body_class', function($classes) {
    $classes[] = 'acorn-creative';
    return $classes;
});


// ============================================
/// DISABLE UNNECESSARY FEATURES
// ============================================
// Remove emoji script — loads from an external CDN, unnecessary attack surface
remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
remove_filter('the_content_feed', 'wp_staticize_emoji');
remove_filter('comment_text_rss', 'wp_staticize_emoji');
remove_filter('wp_mail', 'wp_staticize_emoji_for_email');

// Prevent the site from pinging itself when publishing posts
add_action('pre_ping', function(&$links) {
    foreach ($links as $key => $link) {
        if (str_starts_with($link, home_url())) unset($links[$key]);
    }
});


// ============================================
/// SITE LOGO IN GENERAL SETTINGS
// ============================================

// Keep custom_logo (block logo) in sync when site_logo is saved
add_action('update_option_site_logo', function($old, $new) {
    set_theme_mod('custom_logo', $new);
}, 10, 2);

// Register the setting and field
add_action('admin_init', function() {
    register_setting('general', 'site_logo', ['sanitize_callback' => 'absint']);

    add_settings_field(
        'site_logo',
        'Site Logo',
        'acorn_render_logo_field',
        'general'
    );
});


// Render the logo upload field
function acorn_render_logo_field() {
    $logo_id  = get_option('site_logo');
    $logo_url = $logo_id ? wp_get_attachment_image_url($logo_id, 'medium') : '';
    ?>
    <input type="hidden" name="site_logo" id="site_logo_id" value="<?= esc_attr($logo_id) ?>">

    <?php if ($logo_url) : ?>
        <img id="acorn-logo-preview" src="<?= esc_url($logo_url) ?>" style="max-width: 200px; display: block; margin-bottom: 1rem;">
    <?php else : ?>
        <img id="acorn-logo-preview" src="" style="max-width: 200px; display: none; margin-bottom: 1rem;">
    <?php endif; ?>

    <div class="site-icon-action-buttons">
        <button type="button" id="acorn-logo-upload" class="upload-button button-hero button"
                data-choose-text="Choose a Site Logo"
                data-update-text="Change Site Logo">
            <?= $logo_id ? 'Change Site Logo' : 'Choose a Site Logo' ?>
        </button>
        <button type="button" id="acorn-logo-remove" class="button button-secondary reset <?= $logo_id ? '' : 'hidden' ?>">
            Remove Site Logo
        </button>
    </div>

    <p class="description">The Site Logo appears in your theme header and on the login page. For best results, use an SVG or a PNG with a transparent background.</p>

    <script>
        jQuery(function($) {
            var frame;
            var uploadBtn = $('#acorn-logo-upload');
            var removeBtn = $('#acorn-logo-remove');
            var preview   = $('#acorn-logo-preview');
            var input     = $('#site_logo_id');

            // Move this row to appear directly after the site icon row
            var siteIconRow = $('.site-icon-section');
            if (siteIconRow.length) {
                uploadBtn.closest('tr').insertAfter(siteIconRow);
            }

            uploadBtn.on('click', function(e) {
                e.preventDefault();
                if (frame) { frame.open(); return; }

                frame = wp.media({ title: 'Select Site Logo', button: { text: 'Use this logo' }, multiple: false });

                frame.on('select', function() {
                    var attachment = frame.state().get('selection').first().toJSON();
                    input.val(attachment.id);
                    preview.attr('src', attachment.url).show();
                    uploadBtn.text('Change Site Logo');
                    removeBtn.removeClass('hidden');
                });

                frame.open();
            });

            removeBtn.on('click', function(e) {
                e.preventDefault();
                input.val('');
                preview.attr('src', '').hide();
                uploadBtn.text('Choose a Site Logo');
                removeBtn.addClass('hidden');
            });
        });
    </script>
    <?php
}

// Load media uploader assets on the General Settings page
add_action('admin_enqueue_scripts', function($hook) {
    if ($hook === 'options-general.php') {
        wp_enqueue_media();
    }
});
