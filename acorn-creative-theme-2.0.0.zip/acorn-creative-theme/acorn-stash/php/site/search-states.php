<?php
// =============================================================
//  SEARCH PAGE STATES
// =============================================================
//  Makes the `search` template serve two states from one static template — a
//  landing page when nothing has been searched for, a results page once it
//  has. A block template cannot branch, so three hooks do it instead.
//
//  The core behaviours each hook corrects, and the string contract with that
//  template's `wp_template` post: CLAUDE.md § Search.
//
//  @package Acorn Creative
// =============================================================


// ============================================
/// THE TEST
// ============================================
// WP routes an empty ?s= to search.html on its own — `/?s=` is a search with a
// blank term, and linking a button there is how a visitor reaches the landing
// state. CLAUDE.md § Search.
function acorn_search_is_blank() {
    return is_search() && '' === trim( (string) get_search_query( false ) );
}


// ============================================
/// 1. A BLANK SEARCH RETURNS NOTHING
// ============================================
// Left alone, a blank term returns every published post and the page reads as a
// full archive. Emptying the query is also what lets core/query-no-results
// render. CLAUDE.md § Search.
add_action( 'pre_get_posts', function( $query ) {
    if ( is_admin() || ! $query->is_main_query() || ! $query->is_search() ) {
        return;
    }
    if ( '' !== trim( (string) $query->get( 's' ) ) ) {
        return;
    }

    $query->set( 'post__in', array( 0 ) );
} );


// ============================================
/// 2. THE H1 READS AS A TITLE, NOT AN EMPTY QUOTE
// ============================================
// core/query-title prints 'Search results for: “”' on a blank search. The
// heading TEXT is all that is replaced, matched against core's output shape so
// this no-ops rather than mangling it. CLAUDE.md § Search.
add_filter( 'render_block_core/query-title', function( $block_content, $block ) {
    if ( 'search' !== ( $block['attrs']['type'] ?? '' ) || ! acorn_search_is_blank() ) {
        return $block_content;
    }

    // Parent-owned copy landing on every site, so it is filterable; the
    // "No matches" copy is editable per site in the Site Editor instead.
    $title = apply_filters(
        'acorn_search_blank_title',
        __( 'What are you looking for?', 'acorn-creative' )
    );

    return preg_replace(
        '#(<h[1-6][^>]*>).*(</h[1-6]>)#s',
        '${1}' . esc_html( $title ) . '${2}',
        $block_content,
        1
    );
}, 10, 2 );


// ============================================
/// 3. A LANDING PAGE OR A RESULTS PAGE
// ============================================
// The whole difference between the two states is whether the group wrapping
// core/query survives. CONTRACT: this string must match that group's
// `className` in the site's `search` wp_template POST byte for byte. That
// markup is no longer a file in this theme, so grep cannot check this half —
// CLAUDE.md § Search.
const ACORN_SEARCH_LOOP_CLASS = 'acorn-search-loop';

add_filter( 'render_block', function( $block_content, $block ) {
    $class_name = $block['attrs']['className'] ?? '';

    // Cheap early-out: render_block runs for every block on every request.
    if ( ! is_string( $class_name ) || ! str_contains( $class_name, ACORN_SEARCH_LOOP_CLASS ) ) {
        return $block_content;
    }

    return acorn_search_is_blank() ? '' : $block_content;
}, 10, 2 );


// ============================================
/// BODY CLASS
// ============================================
// So a child can diverge the two states visually without needing a hook
// of its own. The parent ships no CSS for either.
add_filter( 'body_class', function( $classes ) {
    if ( is_search() ) {
        $classes[] = acorn_search_is_blank() ? 'acorn-search-blank' : 'acorn-search-results';
    }

    return $classes;
} );
