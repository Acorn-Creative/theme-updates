<?php
/**
 * Title: Hero — Low
 * Slug: acorn/hero-low
 * Categories: acorn-hero
 * Description: Compact, understated hero — a smaller headline, a short line of copy and a single call to action.
 */
?>
<!-- wp:cover {"dimRatio":100,"overlayColor":"bg-4","isUserOverlayColor":true,"minHeight":10,"minHeightUnit":"rem","isDark":false,"tagName":"section","align":"full","metadata":{"name":"Hero — Low"},"className":"acorn-pattern-hero-low has-bg-4-background-color","style":{"spacing":{"padding":{"top":"var:preset|spacing|medium","right":"0","bottom":"var:preset|spacing|medium","left":"0"},"blockGap":"var:preset|spacing|small"}},"layout":{"type":"constrained"}} -->
<section class="wp-block-cover is-light acorn-pattern-hero-low has-bg-4-background-color alignfull" style="padding-top:var(--wp--preset--spacing--medium);padding-right:0;padding-bottom:var(--wp--preset--spacing--medium);padding-left:0;min-height:10rem"><span aria-hidden="true" class="wp-block-cover__background has-bg-4-background-color has-background-dim-100 has-background-dim"></span><div class="wp-block-cover__inner-container">
<!-- wp:heading {"level":1,"className":"is-style-h2"} -->
<h1 class="wp-block-heading is-style-h2">A concise, low-key headline</h1>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A single supporting sentence — just enough context before the call to action.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|extra-small"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--extra-small)">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Learn more</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
</section>
<!-- /wp:cover -->
