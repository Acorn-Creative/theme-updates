<?php
/**
 * Title: Overlap — Media Over Two Bands
 * Slug: acorn/overlap-media-trio
 * Categories: acorn-overlap
 * Description: Two bands where an image-and-copy row nested at the top of the second one is pulled up over the first.
 *
 * Same structure and the same single `acorn-overlap` class as
 * `acorn/overlap-card-trio` — the row is NESTED as the first block of the lower
 * band, not a band of its own. CLAUDE.md § Patterns.
 *
 * What differs is only the contents of the surface: a two-column row instead of
 * centred copy, so it is taller and padded `large` all round.
 *
 * It therefore sits LOW on the seam rather than centred on it. The shared pull
 * is half a default card's height, and this row is taller — more so once a real
 * image replaces the placeholder. Centring is `half the surface's own height`,
 * which CSS cannot express, so it is not tuned here on purpose: any number
 * picked against an imageless placeholder would be wrong on a real page. If a
 * particular instance needs it centred, set Dimensions -> Margin -> top to half
 * that instance's height, and note the gap above shrinks by what you added,
 * because the forced padding on the band above tracks $overlap-pull, not this.
 *
 * Replace the image placeholder and give it real alt text — it carries meaning
 * here, so it is not decorative.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","metadata":{"name":"Overlap — Band Above"},"className":"acorn-pattern-overlap-media-trio acorn-pattern-overlap-media-trio--above","backgroundColor":"bg-1","style":{"spacing":{"padding":{"top":"var:preset|spacing|humungous","bottom":"var:preset|spacing|humungous"},"blockGap":"var:preset|spacing|small"}},"layout":{"type":"constrained"}} -->
<section class="wp-block-group acorn-pattern-overlap-media-trio acorn-pattern-overlap-media-trio--above alignfull has-global-padding has-bg-1-background-color has-background" style="padding-top:var(--wp--preset--spacing--humungous);padding-bottom:var(--wp--preset--spacing--humungous)">
<!-- wp:heading -->
<h2 class="wp-block-heading">The band the row reaches up into</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Give this band a background image if you like — the row lands on top of whatever is here rather than matching it. Its bottom padding is the one thing set for it, forced by the stylesheet so the space above the row stays constant.</p>
<!-- /wp:paragraph -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","align":"full","metadata":{"name":"Overlap — Band Below"},"className":"acorn-pattern-overlap-media-trio acorn-pattern-overlap-media-trio--below","backgroundColor":"bg-3","style":{"spacing":{"padding":{"top":"var:preset|spacing|medium","bottom":"var:preset|spacing|humungous"},"blockGap":"var:preset|spacing|small"}},"layout":{"type":"constrained"}} -->
<section class="wp-block-group acorn-pattern-overlap-media-trio acorn-pattern-overlap-media-trio--below alignfull has-global-padding has-bg-3-background-color has-background" style="padding-top:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--humungous)">
<!-- wp:group {"metadata":{"name":"Overlap — Media Row"},"className":"acorn-overlap","backgroundColor":"bg-4","style":{"spacing":{"padding":{"top":"var:preset|spacing|large","bottom":"var:preset|spacing|large","left":"var:preset|spacing|large","right":"var:preset|spacing|large"}},"shadow":"var:preset|shadow|shadow-md"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group acorn-overlap has-bg-4-background-color has-background" style="box-shadow:var(--wp--preset--shadow--shadow-md);padding-top:var(--wp--preset--spacing--large);padding-right:var(--wp--preset--spacing--large);padding-bottom:var(--wp--preset--spacing--large);padding-left:var(--wp--preset--spacing--large)">
<!-- wp:columns {"verticalAlignment":"center","style":{"spacing":{"blockGap":{"top":"var:preset|spacing|large","left":"var:preset|spacing|large"}}}} -->
<div class="wp-block-columns are-vertically-aligned-center">
<!-- wp:column {"verticalAlignment":"center"} -->
<div class="wp-block-column is-vertically-aligned-center">
<!-- wp:image {"sizeSlug":"large"} -->
<figure class="wp-block-image size-large"><img alt=""/></figure>
<!-- /wp:image -->
</div>
<!-- /wp:column -->

<!-- wp:column {"verticalAlignment":"center","style":{"spacing":{"blockGap":"var:preset|spacing|small"}}} -->
<div class="wp-block-column is-vertically-aligned-center">
<!-- wp:heading -->
<h2 class="wp-block-heading">One idea, shown and said</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>A row this wide earns its place by straddling the seam, so it should carry the section's single most important claim.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|small"}}}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--small)">
<!-- wp:button {"className":"is-style-secondary"} -->
<div class="wp-block-button is-style-secondary"><a class="wp-block-button__link wp-element-button">Secondary action</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:column -->
</div>
<!-- /wp:columns -->
</div>
<!-- /wp:group -->

<!-- wp:heading -->
<h2 class="wp-block-heading">The band the row belongs to</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>The row is the first block inside this band, so document order matches what you see. This band’s top padding is set by the stylesheet — a small inset the row hangs out of — with <code>humungous</code> below.</p>
<!-- /wp:paragraph -->
</section>
<!-- /wp:group -->
