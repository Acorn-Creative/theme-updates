<?php
/**
 * Title: Hero — Centered
 * Slug: acorn/hero-centered
 * Categories: acorn-hero
 * Description: Centered headline, supporting text and a two-button group on a full-width band.
 */
?>
<!-- wp:cover {"dimRatio":100,"overlayColor":"bg-4","isUserOverlayColor":true,"minHeight":10,"minHeightUnit":"rem","isDark":false,"tagName":"section","align":"full","metadata":{"name":"Hero — Centered"},"className":"acorn-pattern-hero-centered has-bg-4-background-color","style":{"spacing":{"padding":{"top":"var:preset|spacing|humungous","right":"0","bottom":"var:preset|spacing|humungous","left":"0"},"blockGap":"var:preset|spacing|small"}},"layout":{"type":"constrained"}} -->
<section class="wp-block-cover is-light acorn-pattern-hero-centered has-bg-4-background-color alignfull" style="padding-top:var(--wp--preset--spacing--humungous);padding-right:0;padding-bottom:var(--wp--preset--spacing--humungous);padding-left:0;min-height:10rem"><span aria-hidden="true" class="wp-block-cover__background has-bg-4-background-color has-background-dim-100 has-background-dim"></span><div class="wp-block-cover__inner-container">
<!-- wp:heading {"textAlign":"center","level":1} -->
<h1 class="wp-block-heading has-text-align-center">A clear, benefit-led headline</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">One or two supporting sentences that explain the offer and set up the call to action below.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|small"}}},"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--small)">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Primary action</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-secondary"} -->
<div class="wp-block-button is-style-secondary"><a class="wp-block-button__link wp-element-button">Secondary</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
</section>
<!-- /wp:cover -->
