<?php
/**
 * Title: Overlap — Card Over Two Bands
 * Slug: acorn/overlap-card-trio
 * Categories: acorn-overlap
 * Description: Two bands where a card nested at the top of the second one is pulled up over the first.
 *
 * TWO sections, and the card is NESTED as the first block of the lower one —
 * it is not a band of its own. That is the whole design: the card hangs out of
 * the band it belongs to and lands on whatever the band above happens to be, so
 * that band can be a colour, an image or a gradient and nothing has to be
 * repainted to match it.
 *
 * The pull is the single `acorn-overlap` class on the card. Adjust it per
 * instance in Dimensions -> Margin -> top; see the child's `_overlap.scss`.
 *
 * The band above's BOTTOM PADDING IS FORCED by `_overlap.scss` to the gap
 * plus the pull, so the clear space above the card is constant whatever the
 * pull is. Setting that one padding in the editor will not take — deliberate,
 * and the only place in the theme that overrides the editor.
 *
 * The card is a <div>, not a <section> — bands do not nest, and an unnamed
 * <section> is not a landmark anyway. CLAUDE.md § Section semantics.
 */
?>
<!-- wp:group {"tagName":"section","align":"full","metadata":{"name":"Overlap — Band Above"},"className":"acorn-pattern-overlap-card-trio acorn-pattern-overlap-card-trio--above","backgroundColor":"bg-1","style":{"spacing":{"padding":{"top":"var:preset|spacing|humungous","bottom":"var:preset|spacing|humungous"},"blockGap":"var:preset|spacing|small"}},"layout":{"type":"constrained"}} -->
<section class="wp-block-group acorn-pattern-overlap-card-trio acorn-pattern-overlap-card-trio--above alignfull has-global-padding has-bg-1-background-color has-background" style="padding-top:var(--wp--preset--spacing--humungous);padding-bottom:var(--wp--preset--spacing--humungous)">
<!-- wp:heading -->
<h2 class="wp-block-heading">The band the card reaches up into</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Its scheme is free — change the colour or drop in a background image and the card still works, because the card sits on top of it rather than reproducing it. Its <em>bottom</em> padding is not free: the stylesheet forces it to the gap plus the pull, so the space above the card stays the same however deep the pull is.</p>
<!-- /wp:paragraph -->
</section>
<!-- /wp:group -->

<!-- wp:group {"tagName":"section","align":"full","metadata":{"name":"Overlap — Band Below"},"className":"acorn-pattern-overlap-card-trio acorn-pattern-overlap-card-trio--below","backgroundColor":"bg-2","style":{"spacing":{"padding":{"top":"var:preset|spacing|medium","bottom":"var:preset|spacing|humungous"},"blockGap":"var:preset|spacing|small"}},"layout":{"type":"constrained"}} -->
<section class="wp-block-group acorn-pattern-overlap-card-trio acorn-pattern-overlap-card-trio--below alignfull has-global-padding has-bg-2-background-color has-background" style="padding-top:var(--wp--preset--spacing--medium);padding-bottom:var(--wp--preset--spacing--humungous)">
<!-- wp:group {"metadata":{"name":"Overlap — Card"},"className":"acorn-overlap","backgroundColor":"bg-4","style":{"spacing":{"padding":{"top":"var:preset|spacing|medium","bottom":"var:preset|spacing|medium","left":"var:preset|spacing|large","right":"var:preset|spacing|large"},"blockGap":"var:preset|spacing|small"},"shadow":"var:preset|shadow|shadow-md"},"layout":{"type":"constrained"}} -->
<div class="wp-block-group acorn-overlap has-bg-4-background-color has-background" style="box-shadow:var(--wp--preset--shadow--shadow-md);padding-top:var(--wp--preset--spacing--medium);padding-right:var(--wp--preset--spacing--large);padding-bottom:var(--wp--preset--spacing--medium);padding-left:var(--wp--preset--spacing--large)">
<!-- wp:heading {"textAlign":"center"} -->
<h2 class="wp-block-heading has-text-align-center">The point you want read first</h2>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center"} -->
<p class="has-text-align-center">Sitting across the seam is what earns this block its emphasis, so give it one idea and one action — not a second column of copy.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|small"}}},"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--small)">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Primary action</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
<!-- /wp:group -->

<!-- wp:heading -->
<h2 class="wp-block-heading">The band the card belongs to</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>The card is the first block inside this band, so it reads here in document order exactly where it sits on the page. All three of the spacings that make the overlap read — the inset on this band, the card's pull, and the gap under the card — are set together in <code>_overlap.scss</code>, not here.</p>
<!-- /wp:paragraph -->
</section>
<!-- /wp:group -->
