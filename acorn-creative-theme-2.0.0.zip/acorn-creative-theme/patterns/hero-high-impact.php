<?php
/**
 * Title: Hero — High Impact
 * Slug: acorn/hero-high-impact
 * Categories: acorn-hero
 * Description: Maximum-impact centered hero on a dark full-bleed band — eyebrow, oversized headline, intro line and a dual call to action.
 */
?>
<!-- wp:cover {"dimRatio":100,"overlayColor":"bg-1","isUserOverlayColor":true,"minHeight":10,"minHeightUnit":"rem","tagName":"section","align":"full","metadata":{"name":"Hero — High Impact"},"className":"acorn-pattern-hero-high-impact has-bg-1-background-color","style":{"spacing":{"padding":{"top":"var:preset|spacing|humungous","right":"0","bottom":"var:preset|spacing|humungous","left":"0"},"blockGap":"var:preset|spacing|medium"}},"layout":{"type":"constrained"}} -->
<section class="wp-block-cover acorn-pattern-hero-high-impact has-bg-1-background-color alignfull" style="padding-top:var(--wp--preset--spacing--humungous);padding-right:0;padding-bottom:var(--wp--preset--spacing--humungous);padding-left:0;min-height:10rem"><span aria-hidden="true" class="wp-block-cover__background has-bg-1-background-color has-background-dim-100 has-background-dim"></span><div class="wp-block-cover__inner-container">
<!-- wp:paragraph {"align":"center","className":"is-style-pre-header"} -->
<p class="has-text-align-center is-style-pre-header">Introducing</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"textAlign":"center","level":1} -->
<h1 class="wp-block-heading has-text-align-center">The headline that stops the scroll</h1>
<!-- /wp:heading -->

<!-- wp:paragraph {"align":"center","className":"is-style-intro"} -->
<p class="has-text-align-center is-style-intro">A bold, benefit-led sentence that makes the promise impossible to ignore and sets up the action below.</p>
<!-- /wp:paragraph -->

<!-- wp:buttons {"style":{"spacing":{"margin":{"top":"var:preset|spacing|small"}}},"layout":{"type":"flex","justifyContent":"center"}} -->
<div class="wp-block-buttons" style="margin-top:var(--wp--preset--spacing--small)">
<!-- wp:button -->
<div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Get started</a></div>
<!-- /wp:button -->

<!-- wp:button {"className":"is-style-secondary"} -->
<div class="wp-block-button is-style-secondary"><a class="wp-block-button__link wp-element-button">See how it works</a></div>
<!-- /wp:button -->
</div>
<!-- /wp:buttons -->
</div>
</section>
<!-- /wp:cover -->
